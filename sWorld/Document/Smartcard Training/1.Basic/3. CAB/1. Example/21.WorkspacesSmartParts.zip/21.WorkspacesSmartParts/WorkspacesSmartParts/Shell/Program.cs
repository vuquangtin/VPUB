using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace Shell
{
    public class Program : FormShellApplication<WorkItem, Form1>
    {
        [STAThread]
        static void Main()
        {
            new Program().Run();
        }
        protected override void AfterShellCreated()
        {
            base.AfterShellCreated();

            // Both TestClass and UserControl1 are decorated with the SmartPart attribute
            // This means that not only do they get added to the Items collection below, but also they
            // get added to the SmartParts collection on the WorkItem.
            RootWorkItem.SmartParts.AddNew<UserControl1>();
            RootWorkItem.Items.AddNew<TestClass>();

            // UserControl2 is also decorated with the SmartPart attribute, but this has no
            // effect as it doesn't get added to the Items collection or the SmartParts collection]
            // on the WorkItem. It DOES get added to the SmartParts collection on the Workspace as
            // a result of the call to Show below, but this happens whether the attribute is there
            // or not.
            this.Shell.deckWorkspace1.Show(new UserControl2());
            // Can't Show the TestClass as it doesn't inherit Control: it can't
            // be a Workspace SmartPart.  You'll get an exception if you put the
            // line below back in.
            //this.Shell.deckWorkspace1.Show(new TestClass());

            DebugDumpWorkItemCollections(RootWorkItem);
        }

        public static void DebugDumpWorkItemCollections(Microsoft.Practices.CompositeUI.WorkItem workItem)
        {
#if(DEBUG)
            System.Diagnostics.Debug.WriteLine("ITEMS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> coll = workItem.Items;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in coll)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }
            System.Diagnostics.Debug.WriteLine("SMARTPARTS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> sp = workItem.SmartParts;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in sp)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }
            System.Diagnostics.Debug.WriteLine("WORKSPACES:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<Microsoft.Practices.CompositeUI.SmartParts.IWorkspace> ws = workItem.Workspaces;
            foreach (System.Collections.Generic.KeyValuePair<string, Microsoft.Practices.CompositeUI.SmartParts.IWorkspace> o in ws)
            {
                Microsoft.Practices.CompositeUI.SmartParts.IWorkspace workspace = o.Value;
                System.Diagnostics.Debug.WriteLine(o.ToString());
                System.Diagnostics.Debug.WriteLine("\tSMARTPARTS:");
                foreach (object x in workspace.SmartParts)
                {
                    System.Diagnostics.Debug.WriteLine("\t" + x.ToString());
                }

            }
#endif
        }
    }

    [SmartPart]
    internal class TestClass {}
}