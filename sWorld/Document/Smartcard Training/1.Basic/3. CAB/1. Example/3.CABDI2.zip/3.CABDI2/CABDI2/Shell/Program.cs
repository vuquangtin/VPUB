using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;

namespace Shell
{
    public class Program : FormShellApplication<WorkItem, Form1>
    {
        [STAThread]
        static void Main()
        {
            new Program().Run();
        }
        WorkItem testWorkItem = null;
        protected override void AfterShellCreated()
        {
            testWorkItem = RootWorkItem.WorkItems.AddNew<WorkItem>();
            // Change the line below to AddNew to testWorkItem to get this code to work
            RootWorkItem.Items.AddNew<Component1>("FirstComponent1");
            // The next line throws an exception as the testWorkItem
            // container doesn't know about FirstComponent1, and Component2
            // is asking for it to be injected.
            testWorkItem.Items.AddNew<Component2>();
            DisplayRootItemsCollection();
        }

        private void DisplayRootItemsCollection()
        {
            System.Diagnostics.Debug.WriteLine("ITEMS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> coll = testWorkItem.Items;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in coll)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }
        }
    }
}