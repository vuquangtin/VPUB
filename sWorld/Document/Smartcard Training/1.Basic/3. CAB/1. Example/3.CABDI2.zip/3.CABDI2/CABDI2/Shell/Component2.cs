using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.ObjectBuilder;

namespace Shell
{
    public class Component2
    {
        private Component1 component11;
        [ComponentDependency("FirstComponent1")]
        public Component1 Component11
        {
            set { component11 = value; }
        }

        private Component1 component12;
        [CreateNew]
        public Component1 Component12
        {
            set { component12 = value; }
        }
    }
}
