using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;

namespace CABCommandCustomEvents
{
    public class Program : FormShellApplication<WorkItem, Shell>
    {
        [STAThread]
        static void Main()
        {
            new Program().Run();
        }
        protected override void AfterShellCreated()
        {
            base.AfterShellCreated();

            RaiseStandardDotNetEvent();
            ExecuteCABCommand();
        }

        private static void RaiseStandardDotNetEvent()
        {
            // Example code to remind us of how we raise and sink .NET events

            // Define an event in a class...
            RichEventRaiser richEventRaiser = new RichEventRaiser();
            // Define a class with a method that will handle the event...
            RichEventSinkDotNet richEventSinkDotNet = new RichEventSinkDotNet();
            // Hook the method that handles the event to the event using the usual syntax...
            richEventRaiser.RichEvent += new EventHandler(richEventSinkDotNet.RichEventSink);
            // Raise the event, and the method to handle the event gets called
            richEventRaiser.OnRichEvent();
        }

        private void ExecuteCABCommand()
        {
            // Example code to do the equivalent using CAB commands

            // The same class is our invoker, the event 'invokes' the command
            RichEventRaiser richEventRaiser2 = RootWorkItem.Items.AddNew<RichEventRaiser>();
            // The method to handle the event has the same signature, but now we decorate it with the 
            // CommandHandler attribute with the command name as a parameter: this is all we need to 
            // do to hook our command to our command handler (the receiver)
            RichEventSinkCABCommand richEventSinkCABCommand = RootWorkItem.Items.AddNew<RichEventSinkCABCommand>();

            // We now need to hook our command to our invoker (the event in RichEventRaiser).  
            // We can't call AddInvoker on general .NET events without setting up a command adapter
            // Fortunately there is a generic EventCommandAdapter<> class we can use for this:
            // we need to add that and our invoker class into the MapService as below.
            ICommandAdapterMapService mapService = RootWorkItem.Services.Get<ICommandAdapterMapService>();
            mapService.Register(typeof(RichEventRaiser), typeof(EventCommandAdapter<RichEventRaiser>));

            // Access the command by name...
            Command command = RootWorkItem.Commands["RichCommand"];
            // Call AddInvoker with the event details to hook it up
            command.AddInvoker(richEventRaiser2, "RichEvent");

            // Now fire the .NET event, which invokes the command which finds the command handler and calls it
            richEventRaiser2.OnRichEvent();

            DisplayRootItemsCollection(RootWorkItem);
        }


        private void DisplayRootItemsCollection(WorkItem workItem)
        {
            System.Diagnostics.Debug.WriteLine("ITEMS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> coll = workItem.Items;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in coll)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }

            System.Diagnostics.Debug.WriteLine("COMMANDS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<Microsoft.Practices.CompositeUI.Commands.Command> cm = workItem.Commands;
            foreach (System.Collections.Generic.KeyValuePair<string, Microsoft.Practices.CompositeUI.Commands.Command> o in cm)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
                Command c = (Command)o.Value;
                foreach (object a in c.Adapters)
                {
                    System.Diagnostics.Debug.WriteLine("\t" + a.ToString());
                }
            }
        }
    }
}