using System;
using System.Windows.Forms;

namespace CABCommandCustomEvents
{
    public class RichEventSinkDotNet
    {
        public void RichEventSink(object sender, EventArgs e)
        {
            MessageBox.Show("Hello from the .NET event sink");
        }
    }
}
