using System;
using System.Windows.Forms;

namespace CABCommandCustomEvents
{
    /// <summary>
    /// Standard class with an event that can be raised
    /// </summary>
    public class RichEventRaiser
    {
        public event EventHandler RichEvent;

        public void OnRichEvent()
        {
            if (RichEvent != null)
                RichEvent(this, EventArgs.Empty);
        }
    }
}
