using System;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;

namespace CABCommandCustomEvents
{
    public class RichEventSinkCABCommand
    {
        [CommandHandler("RichCommand")]
        public void RichCommandHandler(object sender, EventArgs e)
        {
            MessageBox.Show("Hello from the CAB command handler");
        }
    }
}
