using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.CompositeUI;

namespace Shell
{
    public class MyService
    {
        public MyService()
        {
            System.Diagnostics.Debug.WriteLine("MyService constructor called");
        }
        public string GetHello()
        {
            return "Hello World";
        }
    }
}
