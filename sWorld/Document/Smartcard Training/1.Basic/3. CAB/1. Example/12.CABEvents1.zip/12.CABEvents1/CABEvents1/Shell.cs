using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.EventBroker;

namespace CABEvents1
{
    public partial class Shell : Form
    {
        public Shell()
        {
            InitializeComponent();
        }

        private WorkItem workItem;
        [ServiceDependency]
        public WorkItem WorkItem
        {
            set { workItem = value; }
        }

        private void cabEventFirerButton_Click(object sender, EventArgs e)
        {
            Publisher publisher = workItem.Items.Get<Publisher>("Publisher");
            publisher.FireMyEvent();
        }

        private void cabEventFirerDirectlyButton_Click(object sender, EventArgs e)
        {
            workItem.EventTopics["MyEvent"].Fire(this, EventArgs.Empty, null, PublicationScope.Global);
        }        
    }
}