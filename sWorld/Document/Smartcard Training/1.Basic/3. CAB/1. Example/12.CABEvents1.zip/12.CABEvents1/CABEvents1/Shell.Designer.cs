namespace CABEvents1
{
    partial class Shell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cabEventFirerButton = new System.Windows.Forms.Button();
            this.cabEventFirerDirectlyButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cabEventFirerButton
            // 
            this.cabEventFirerButton.Location = new System.Drawing.Point(31, 32);
            this.cabEventFirerButton.Name = "cabEventFirerButton";
            this.cabEventFirerButton.Size = new System.Drawing.Size(110, 43);
            this.cabEventFirerButton.TabIndex = 0;
            this.cabEventFirerButton.Text = "Fire CAB Event via Publisher Class";
            this.cabEventFirerButton.UseVisualStyleBackColor = true;
            this.cabEventFirerButton.Click += new System.EventHandler(this.cabEventFirerButton_Click);
            // 
            // cabEventFirerDirectlyButton
            // 
            this.cabEventFirerDirectlyButton.Location = new System.Drawing.Point(172, 32);
            this.cabEventFirerDirectlyButton.Name = "cabEventFirerDirectlyButton";
            this.cabEventFirerDirectlyButton.Size = new System.Drawing.Size(110, 43);
            this.cabEventFirerDirectlyButton.TabIndex = 1;
            this.cabEventFirerDirectlyButton.Text = "Fire CAB Event Directly";
            this.cabEventFirerDirectlyButton.UseVisualStyleBackColor = true;
            this.cabEventFirerDirectlyButton.Click += new System.EventHandler(this.cabEventFirerDirectlyButton_Click);
            // 
            // Shell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 497);
            this.Controls.Add(this.cabEventFirerDirectlyButton);
            this.Controls.Add(this.cabEventFirerButton);
            this.Name = "Shell";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cabEventFirerButton;
        private System.Windows.Forms.Button cabEventFirerDirectlyButton;

    }
}

