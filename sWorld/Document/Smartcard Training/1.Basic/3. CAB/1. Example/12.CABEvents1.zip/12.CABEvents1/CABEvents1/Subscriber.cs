using System;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.EventBroker;

namespace CABEvents1
{
    public class Subscriber
    {
        [EventSubscription("MyEvent")]
        public void MyEventHandler(object sender, EventArgs e)
        {
            MessageBox.Show("Hello from the CAB event handler");
        }
    }
}
