using System;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.EventBroker;

namespace CABEvents1
{
    /// <summary>
    /// Standard class with an event that can be fired
    /// </summary>
    public class Publisher
    {
        private WorkItem workItem;
        [ServiceDependency]
        public WorkItem WorkItem
        {
            set { workItem = value; }
        }
        
        public void FireMyEvent()
        {
            workItem.EventTopics["MyEvent"].Fire(this, EventArgs.Empty, null, PublicationScope.Global);
        }
    }
}
