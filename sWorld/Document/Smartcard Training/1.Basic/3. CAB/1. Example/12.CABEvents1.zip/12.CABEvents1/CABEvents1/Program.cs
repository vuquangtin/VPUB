using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;

namespace CABEvents1
{
    public class Program : FormShellApplication<WorkItem, Shell>
    {
        [STAThread]
        static void Main()
        {
            new Program().Run();
        }
        protected override void AfterShellCreated()
        {
            base.AfterShellCreated();
            RootWorkItem.Items.AddNew<Subscriber>();
            RootWorkItem.Items.AddNew<Subscriber2>();
            RootWorkItem.Items.AddNew<Publisher>("Publisher");
        }
    }
}