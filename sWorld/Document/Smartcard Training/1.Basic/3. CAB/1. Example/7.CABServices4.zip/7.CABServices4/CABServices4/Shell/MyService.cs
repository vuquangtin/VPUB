using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.WinForms;

namespace Shell
{
    public class MyService : IMyService
    {
        public MyService()
        {
            System.Diagnostics.Debug.WriteLine("Being created");
        }
        public string GetHello()
        {
            return "Hello World";
        }
    }
}
