using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace Shell
{
    public partial class ShellForm : Form, ISmartPartInfoProvider
    {
        private WorkItem rootWorkItem;
        [ServiceDependency]
        public WorkItem WorkItem { set { rootWorkItem = value; } }
        MdiWorkspace mdiWorkspace; 

        public ShellForm()
        {
            InitializeComponent();
            mdiWorkspace = new MdiWorkspace(this);
        }

        RedSmartPart redSmartPart = new RedSmartPart();
        BlueSmartPart blueSmartPart = new BlueSmartPart();

        #region mdiWorkspace button handlers

        private void mdiShowRedButton_Click(object sender, EventArgs e)
        {
            this.mdiWorkspace.Show(redSmartPart, this.redWindowSmartPartInfo);
        }

        private void mdiShowBlueButton_Click(object sender, EventArgs e)
        {
            this.mdiWorkspace.Show(blueSmartPart, this.blueWindowSmartPartInfo);
        }

        private void mdiCloseRedButton_Click(object sender, EventArgs e)
        {
            this.mdiWorkspace.Close(redSmartPart);
        }

        private void mdiCloseBlueButton_Click(object sender, EventArgs e)
        {
            this.mdiWorkspace.Close(blueSmartPart);
        }

        private void mdiActivateRedButton_Click(object sender, EventArgs e)
        {
            this.mdiWorkspace.Activate(redSmartPart);
        }

        private void mdiActivateBlueButton_Click(object sender, EventArgs e)
        {
            this.mdiWorkspace.Activate(blueSmartPart);
        }

        private void mdiHideRedButton_Click(object sender, EventArgs e)
        {
            this.mdiWorkspace.Hide(redSmartPart);
        }

        private void mdiHideBlueButton_Click(object sender, EventArgs e)
        {
            this.mdiWorkspace.Hide(blueSmartPart);
        }

        private void mdiApplySmartPartInfoRedButton_Click(object sender, EventArgs e)
        {
            redWindowSmartPartInfo.Title = newNameTextBox.Text;
            this.mdiWorkspace.ApplySmartPartInfo(redSmartPart, redWindowSmartPartInfo);
        }

        private void mdiApplySmartPartInfoBlueButton_Click(object sender, EventArgs e)
        {
            blueWindowSmartPartInfo.Title = newNameTextBox.Text;
            this.mdiWorkspace.ApplySmartPartInfo(blueSmartPart, blueWindowSmartPartInfo);
        }

        #endregion

        public Microsoft.Practices.CompositeUI.SmartParts.ISmartPartInfo GetSmartPartInfo(Type smartPartInfoType)
        {
            // Implement ISmartPartInfoProvider in the containing smart part. Required in order for contained smart part infos to work.
            Microsoft.Practices.CompositeUI.SmartParts.ISmartPartInfoProvider ensureProvider = this;
            return this.infoProvider.GetSmartPartInfo(smartPartInfoType);

        }

    }
}