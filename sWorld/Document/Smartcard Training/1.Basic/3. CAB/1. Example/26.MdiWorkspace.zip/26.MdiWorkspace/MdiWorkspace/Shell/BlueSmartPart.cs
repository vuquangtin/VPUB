using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace Shell
{
    [SmartPart]
    public partial class BlueSmartPart : UserControl
    {
        public BlueSmartPart()
        {
            InitializeComponent();
        }
    }
}
