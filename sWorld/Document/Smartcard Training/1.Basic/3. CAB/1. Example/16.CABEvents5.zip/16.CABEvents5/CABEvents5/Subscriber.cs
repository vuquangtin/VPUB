using System;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.EventBroker;
using Microsoft.Practices.CompositeUI;

namespace CABEvents5
{
    public class Subscriber
    {
        private WorkItem rootWorkItem;
        [ServiceDependency]
        public WorkItem RootWorkItem
        {
            set
            {
                rootWorkItem = value;
            }
        }

        [EventSubscription("MyEvent")]
        public void MyEventHandler(object sender, EventArgs e)
        {            
            ShowPublicationsSubscriptionsMessage();
        }

        public void ShowPublicationsSubscriptionsMessage()
        {
            EventTopic et = rootWorkItem.EventTopics["MyEvent"];
            string message = "EventTopic MyEvent\r\n";
            message += "Number of publications = " + et.PublicationCount.ToString() + "\r\n";
            message += "Number of subscriptions = " + et.SubscriptionCount.ToString() + "\r\n";
            if (et.ContainsSubscription(this, "MyEventHandler") && et.SubscriptionCount == 1)
                message += "Subscription is MyEventHandler in class Subscriber\r\n";
            MessageBox.Show(message);
        }
    }
}
