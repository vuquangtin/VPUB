namespace Shell
{
    partial class ShellForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.deckWorkspace = new Microsoft.Practices.CompositeUI.WinForms.DeckWorkspace();
            this.deckShowRedButton = new System.Windows.Forms.Button();
            this.deckCloseRedButton = new System.Windows.Forms.Button();
            this.deckActivateRedButton = new System.Windows.Forms.Button();
            this.deckHideRedButton = new System.Windows.Forms.Button();
            this.deckHideBlueButton = new System.Windows.Forms.Button();
            this.deckActivateBlueButton = new System.Windows.Forms.Button();
            this.deckCloseBlueButton = new System.Windows.Forms.Button();
            this.deckShowBlueButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.infoProvider = new Microsoft.Practices.CompositeUI.SmartParts.SmartPartInfoProvider();
            this.showWorkItemDetailsButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // deckWorkspace
            // 
            this.deckWorkspace.BackColor = System.Drawing.SystemColors.ControlDark;
            this.deckWorkspace.Location = new System.Drawing.Point(0, 0);
            this.deckWorkspace.Name = "deckWorkspace";
            this.deckWorkspace.Size = new System.Drawing.Size(371, 208);
            this.deckWorkspace.TabIndex = 0;
            this.deckWorkspace.Text = "deckWorkspace1";
            // 
            // deckShowRedButton
            // 
            this.deckShowRedButton.Location = new System.Drawing.Point(380, 45);
            this.deckShowRedButton.Name = "deckShowRedButton";
            this.deckShowRedButton.Size = new System.Drawing.Size(56, 23);
            this.deckShowRedButton.TabIndex = 3;
            this.deckShowRedButton.Text = "Show";
            this.deckShowRedButton.UseVisualStyleBackColor = true;
            this.deckShowRedButton.Click += new System.EventHandler(this.deckShowRedButton_Click);
            // 
            // deckCloseRedButton
            // 
            this.deckCloseRedButton.Location = new System.Drawing.Point(380, 74);
            this.deckCloseRedButton.Name = "deckCloseRedButton";
            this.deckCloseRedButton.Size = new System.Drawing.Size(56, 23);
            this.deckCloseRedButton.TabIndex = 4;
            this.deckCloseRedButton.Text = "Close";
            this.deckCloseRedButton.UseVisualStyleBackColor = true;
            this.deckCloseRedButton.Click += new System.EventHandler(this.deckCloseRedButton_Click);
            // 
            // deckActivateRedButton
            // 
            this.deckActivateRedButton.Location = new System.Drawing.Point(380, 103);
            this.deckActivateRedButton.Name = "deckActivateRedButton";
            this.deckActivateRedButton.Size = new System.Drawing.Size(56, 23);
            this.deckActivateRedButton.TabIndex = 5;
            this.deckActivateRedButton.Text = "Activate";
            this.deckActivateRedButton.UseVisualStyleBackColor = true;
            this.deckActivateRedButton.Click += new System.EventHandler(this.deckActivateRedButton_Click);
            // 
            // deckHideRedButton
            // 
            this.deckHideRedButton.Location = new System.Drawing.Point(380, 132);
            this.deckHideRedButton.Name = "deckHideRedButton";
            this.deckHideRedButton.Size = new System.Drawing.Size(56, 23);
            this.deckHideRedButton.TabIndex = 6;
            this.deckHideRedButton.Text = "Hide";
            this.deckHideRedButton.UseVisualStyleBackColor = true;
            this.deckHideRedButton.Click += new System.EventHandler(this.deckHideRedButton_Click);
            // 
            // deckHideBlueButton
            // 
            this.deckHideBlueButton.Location = new System.Drawing.Point(442, 132);
            this.deckHideBlueButton.Name = "deckHideBlueButton";
            this.deckHideBlueButton.Size = new System.Drawing.Size(56, 23);
            this.deckHideBlueButton.TabIndex = 10;
            this.deckHideBlueButton.Text = "Hide";
            this.deckHideBlueButton.UseVisualStyleBackColor = true;
            this.deckHideBlueButton.Click += new System.EventHandler(this.deckHideBlueButton_Click);
            // 
            // deckActivateBlueButton
            // 
            this.deckActivateBlueButton.Location = new System.Drawing.Point(442, 103);
            this.deckActivateBlueButton.Name = "deckActivateBlueButton";
            this.deckActivateBlueButton.Size = new System.Drawing.Size(56, 23);
            this.deckActivateBlueButton.TabIndex = 9;
            this.deckActivateBlueButton.Text = "Activate";
            this.deckActivateBlueButton.UseVisualStyleBackColor = true;
            this.deckActivateBlueButton.Click += new System.EventHandler(this.deckActivateBlueButton_Click);
            // 
            // deckCloseBlueButton
            // 
            this.deckCloseBlueButton.Location = new System.Drawing.Point(442, 74);
            this.deckCloseBlueButton.Name = "deckCloseBlueButton";
            this.deckCloseBlueButton.Size = new System.Drawing.Size(56, 23);
            this.deckCloseBlueButton.TabIndex = 8;
            this.deckCloseBlueButton.Text = "Close";
            this.deckCloseBlueButton.UseVisualStyleBackColor = true;
            this.deckCloseBlueButton.Click += new System.EventHandler(this.deckCloseBlueButton_Click);
            // 
            // deckShowBlueButton
            // 
            this.deckShowBlueButton.Location = new System.Drawing.Point(442, 45);
            this.deckShowBlueButton.Name = "deckShowBlueButton";
            this.deckShowBlueButton.Size = new System.Drawing.Size(56, 23);
            this.deckShowBlueButton.TabIndex = 7;
            this.deckShowBlueButton.Text = "Show";
            this.deckShowBlueButton.UseVisualStyleBackColor = true;
            this.deckShowBlueButton.Click += new System.EventHandler(this.deckShowBlueButton_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(377, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 30);
            this.label1.TabIndex = 11;
            this.label1.Text = "Red SmartPart";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(439, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 30);
            this.label2.TabIndex = 12;
            this.label2.Text = "Blue SmartPart";
            // 
            // showWorkItemDetailsButton
            // 
            this.showWorkItemDetailsButton.Location = new System.Drawing.Point(414, 161);
            this.showWorkItemDetailsButton.Name = "showWorkItemDetailsButton";
            this.showWorkItemDetailsButton.Size = new System.Drawing.Size(56, 23);
            this.showWorkItemDetailsButton.TabIndex = 13;
            this.showWorkItemDetailsButton.Text = "Details";
            this.showWorkItemDetailsButton.UseVisualStyleBackColor = true;
            this.showWorkItemDetailsButton.Click += new System.EventHandler(this.showWorkItemDetailsButton_Click);
            // 
            // ShellForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 209);
            this.Controls.Add(this.showWorkItemDetailsButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.deckHideBlueButton);
            this.Controls.Add(this.deckActivateBlueButton);
            this.Controls.Add(this.deckCloseBlueButton);
            this.Controls.Add(this.deckShowBlueButton);
            this.Controls.Add(this.deckHideRedButton);
            this.Controls.Add(this.deckActivateRedButton);
            this.Controls.Add(this.deckCloseRedButton);
            this.Controls.Add(this.deckShowRedButton);
            this.Controls.Add(this.deckWorkspace);
            this.Name = "ShellForm";
            this.Text = "DeckWorkspace Example";
            this.ResumeLayout(false);

        }

        #endregion

        internal Microsoft.Practices.CompositeUI.WinForms.DeckWorkspace deckWorkspace;
        private System.Windows.Forms.Button deckShowRedButton;
        private System.Windows.Forms.Button deckCloseRedButton;
        private System.Windows.Forms.Button deckActivateRedButton;
        private System.Windows.Forms.Button deckHideRedButton;
        private System.Windows.Forms.Button deckHideBlueButton;
        private System.Windows.Forms.Button deckActivateBlueButton;
        private System.Windows.Forms.Button deckCloseBlueButton;
        private System.Windows.Forms.Button deckShowBlueButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Microsoft.Practices.CompositeUI.SmartParts.SmartPartInfoProvider infoProvider;
        private System.Windows.Forms.Button showWorkItemDetailsButton;

    }
}

