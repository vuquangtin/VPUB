using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Shell
{
    public partial class LinkLabelPanel : UserControl
    {
        public LinkLabelPanel()
        {
            InitializeComponent();
        }

        private const int labelSpacing = 22;
        private int nextLabelTop = 10;
        private const int left = 3;

        public void AddLabel(LinkLabel label)
        {
            label.Location = new Point(left, nextLabelTop);
            nextLabelTop += labelSpacing;
            this.Controls.Add(label);
        }

        public void RemoveLabel(LinkLabel label)
        {
            this.Controls.Remove(label);
        }
    }
}
