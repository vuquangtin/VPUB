using Microsoft.Practices.CompositeUI;
using System.Windows.Forms;

namespace Red
{
    public class RedModuleInit : ModuleInit
    {
        private WorkItem parentWorkItem;

        [ServiceDependency]
        public WorkItem ParentWorkItem
        {
            set { parentWorkItem = value; }
        }

        private Form1 form;
        public override void Load()
        {
            // Code as before
            base.Load();
            Form shell = (Form)parentWorkItem.Items["Shell"];
            form = new Form1();
            form.MdiParent = shell;
            form.Show();

            LinkLabel label = new LinkLabel();
            label.Text = "Show Red Screen";
            label.Click += new System.EventHandler(label_Click);
            UIExtensionSite uiExtensionSite = parentWorkItem.UIExtensionSites["LinkLabelPanel"];
            uiExtensionSite.Add<LinkLabel>(label);
        }

        void label_Click(object sender, System.EventArgs e)
        {
            form.BringToFront();
        }
    }
}
