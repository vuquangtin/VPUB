using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.CompositeUI.UIElements;
using System.Windows.Forms;

namespace Shell
{
    public class LinkLabelPanelUIAdapter : UIElementAdapter<LinkLabel>
    {
        LinkLabelPanel panel;
        public LinkLabelPanelUIAdapter(LinkLabelPanel panel)
        {
            this.panel = panel;
        }

        protected override LinkLabel Add(LinkLabel uiElement)
        {
            panel.AddLabel(uiElement);
            return uiElement;
        }

        protected override void Remove(LinkLabel uiElement)
        {
            panel.RemoveLabel(uiElement);
        }
    }
}
