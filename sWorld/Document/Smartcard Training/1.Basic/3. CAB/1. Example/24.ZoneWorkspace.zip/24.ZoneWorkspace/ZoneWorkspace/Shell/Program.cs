using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace Shell
{
    public class Program : FormShellApplication<WorkItem, ShellForm>
    {
        [STAThread]
        static void Main()
        {
            // Ensure all our thread exceptions are handled
            System.Windows.Forms.Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
            new Program().Run();
        }

        static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            System.Windows.Forms.MessageBox.Show(e.Exception.Message, e.Exception.GetType().ToString());
        }
        protected override void AfterShellCreated()
        {
            base.AfterShellCreated();
        }
    }
}