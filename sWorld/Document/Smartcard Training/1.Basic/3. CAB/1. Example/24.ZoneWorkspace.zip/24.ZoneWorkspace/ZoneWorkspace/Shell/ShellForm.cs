using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace Shell
{
    public partial class ShellForm : Form, ISmartPartInfoProvider
    {
        private WorkItem rootWorkItem;
        [ServiceDependency]
        public WorkItem WorkItem { set { rootWorkItem = value; } }

        public ShellForm()
        {
            InitializeComponent();
            smartPartInfo = zoneSmartPartInfoLeftZone;
        }

        RedSmartPart redSmartPart = new RedSmartPart();
        BlueSmartPart blueSmartPart = new BlueSmartPart();

        #region ZoneWorkspace button handlers

        ZoneSmartPartInfo smartPartInfo;

        private void zoneShowRedButton_Click(object sender, EventArgs e)
        {
            this.zoneWorkspace.Show(redSmartPart, smartPartInfo);
        }

        private void zoneShowBlueButton_Click(object sender, EventArgs e)
        {
            this.zoneWorkspace.Show(blueSmartPart, smartPartInfo);
        }

        private void zoneCloseRedButton_Click(object sender, EventArgs e)
        {
            this.zoneWorkspace.Close(redSmartPart);
        }

        private void zoneCloseBlueButton_Click(object sender, EventArgs e)
        {
            this.zoneWorkspace.Close(blueSmartPart);
        }

        private void zoneActivateRedButton_Click(object sender, EventArgs e)
        {
            this.zoneWorkspace.Activate(redSmartPart);
        }

        private void zoneActivateBlueButton_Click(object sender, EventArgs e)
        {
            this.zoneWorkspace.Activate(blueSmartPart);
        }

        private void zoneHideRedButton_Click(object sender, EventArgs e)
        {
            this.zoneWorkspace.Hide(redSmartPart);
        }

        private void zoneHideBlueButton_Click(object sender, EventArgs e)
        {
            this.zoneWorkspace.Hide(blueSmartPart);
        }

        private void zoneApplySmartPartInfoRedButton_Click(object sender, EventArgs e)
        {
            this.zoneWorkspace.ApplySmartPartInfo(redSmartPart, smartPartInfo);
        }

        private void zoneApplySmartPartInfoBlueButton_Click(object sender, EventArgs e)
        {
            this.zoneWorkspace.ApplySmartPartInfo(blueSmartPart, smartPartInfo);
        }

        private void leftZoneRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (leftZoneRadioButton.Checked) smartPartInfo = zoneSmartPartInfoLeftZone;
        }

        private void rightZoneRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (rightZoneRadioButton.Checked) smartPartInfo = zoneSmartPartInfoRightZone;
        }

        #endregion

        public Microsoft.Practices.CompositeUI.SmartParts.ISmartPartInfo GetSmartPartInfo(Type smartPartInfoType)
        {
            // Implement ISmartPartInfoProvider in the containing smart part. Required in order for contained smart part infos to work.
            Microsoft.Practices.CompositeUI.SmartParts.ISmartPartInfoProvider ensureProvider = this;
            return this.infoProvider.GetSmartPartInfo(smartPartInfoType);

        }

        #region Show details button handler
        private void showWorkItemDetailsButton_Click(object sender, EventArgs e)
        {
            string message = "Active SmartPart: ";
            if (zoneWorkspace.ActiveSmartPart != null)
                message += this.zoneWorkspace.ActiveSmartPart;
            else
                message += " Not set";
            message += "\r\n\r\nROOTWORKITEM COLLECTIONS:\r\n\r\n";
            string workItemDetails = this.WorkItemCollectionDetails(rootWorkItem);
            message += workItemDetails;
            MessageBox.Show(message);
        }

        private string WorkItemCollectionDetails(Microsoft.Practices.CompositeUI.WorkItem workItem)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("ITEMS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> coll = workItem.Items;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in coll)
            {
                sb.AppendLine(o.ToString());
            }
            System.Diagnostics.Debug.WriteLine("SMARTPARTS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> sp = workItem.SmartParts;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in sp)
            {
                sb.AppendLine(o.ToString());
            }
            sb.AppendLine("WORKSPACES:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<Microsoft.Practices.CompositeUI.SmartParts.IWorkspace> ws = workItem.Workspaces;
            foreach (System.Collections.Generic.KeyValuePair<string, Microsoft.Practices.CompositeUI.SmartParts.IWorkspace> o in ws)
            {
                Microsoft.Practices.CompositeUI.SmartParts.IWorkspace workspace = o.Value;
                sb.AppendLine(o.ToString());
                sb.AppendLine("\tSMARTPARTS:");
                foreach (object x in workspace.SmartParts)
                {
                    sb.AppendLine("\t" + x.ToString());
                }
            }
            return sb.ToString();
        }
        #endregion

    }
}