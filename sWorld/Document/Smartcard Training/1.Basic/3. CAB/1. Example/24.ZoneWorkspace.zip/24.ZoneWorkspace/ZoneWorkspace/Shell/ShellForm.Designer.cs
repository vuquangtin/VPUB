namespace Shell
{
    partial class ShellForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.zoneWorkspace = new Microsoft.Practices.CompositeUI.WinForms.ZoneWorkspace();
            this.rightZone = new System.Windows.Forms.Panel();
            this.leftZone = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.zoneHideBlueButton = new System.Windows.Forms.Button();
            this.zoneActivateBlueButton = new System.Windows.Forms.Button();
            this.zoneCloseBlueButton = new System.Windows.Forms.Button();
            this.zoneShowBlueButton = new System.Windows.Forms.Button();
            this.zoneHideRedButton = new System.Windows.Forms.Button();
            this.zoneActivateRedButton = new System.Windows.Forms.Button();
            this.zoneCloseRedButton = new System.Windows.Forms.Button();
            this.zoneShowRedButton = new System.Windows.Forms.Button();
            this.zoneSmartPartInfoLeftZone = new Microsoft.Practices.CompositeUI.WinForms.ZoneSmartPartInfo();
            this.infoProvider = new Microsoft.Practices.CompositeUI.SmartParts.SmartPartInfoProvider();
            this.zoneSmartPartInfoRightZone = new Microsoft.Practices.CompositeUI.WinForms.ZoneSmartPartInfo();
            this.leftZoneRadioButton = new System.Windows.Forms.RadioButton();
            this.rightZoneRadioButton = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.zoneApplySmartPartInfoBlueButton = new System.Windows.Forms.Button();
            this.zoneApplySmartPartInfoRedButton = new System.Windows.Forms.Button();
            this.showWorkItemDetailsButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.zoneWorkspace)).BeginInit();
            this.zoneWorkspace.SuspendLayout();
            this.SuspendLayout();
            // 
            // zoneWorkspace
            // 
            this.zoneWorkspace.BackColor = System.Drawing.SystemColors.ControlDark;
            this.zoneWorkspace.Controls.Add(this.rightZone);
            this.zoneWorkspace.Controls.Add(this.leftZone);
            this.zoneWorkspace.Location = new System.Drawing.Point(12, 6);
            this.zoneWorkspace.Name = "zoneWorkspace";
            this.zoneWorkspace.Size = new System.Drawing.Size(301, 293);
            this.zoneWorkspace.TabIndex = 1;
            // 
            // rightZone
            // 
            this.rightZone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.rightZone.Location = new System.Drawing.Point(148, 4);
            this.rightZone.Name = "rightZone";
            this.rightZone.Size = new System.Drawing.Size(148, 286);
            this.rightZone.TabIndex = 1;
            this.zoneWorkspace.SetZoneName(this.rightZone, "RightZone");
            // 
            // leftZone
            // 
            this.leftZone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.leftZone.Location = new System.Drawing.Point(4, 4);
            this.leftZone.Name = "leftZone";
            this.leftZone.Size = new System.Drawing.Size(138, 286);
            this.leftZone.TabIndex = 0;
            this.zoneWorkspace.SetZoneName(this.leftZone, "LeftZone");
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(388, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 30);
            this.label3.TabIndex = 22;
            this.label3.Text = "Blue SmartPart";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(326, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 30);
            this.label4.TabIndex = 21;
            this.label4.Text = "Red SmartPart";
            // 
            // zoneHideBlueButton
            // 
            this.zoneHideBlueButton.Location = new System.Drawing.Point(391, 127);
            this.zoneHideBlueButton.Name = "zoneHideBlueButton";
            this.zoneHideBlueButton.Size = new System.Drawing.Size(56, 23);
            this.zoneHideBlueButton.TabIndex = 20;
            this.zoneHideBlueButton.Text = "Hide";
            this.zoneHideBlueButton.UseVisualStyleBackColor = true;
            this.zoneHideBlueButton.Click += new System.EventHandler(this.zoneHideBlueButton_Click);
            // 
            // zoneActivateBlueButton
            // 
            this.zoneActivateBlueButton.Location = new System.Drawing.Point(391, 98);
            this.zoneActivateBlueButton.Name = "zoneActivateBlueButton";
            this.zoneActivateBlueButton.Size = new System.Drawing.Size(56, 23);
            this.zoneActivateBlueButton.TabIndex = 19;
            this.zoneActivateBlueButton.Text = "Activate";
            this.zoneActivateBlueButton.UseVisualStyleBackColor = true;
            this.zoneActivateBlueButton.Click += new System.EventHandler(this.zoneActivateBlueButton_Click);
            // 
            // zoneCloseBlueButton
            // 
            this.zoneCloseBlueButton.Location = new System.Drawing.Point(391, 69);
            this.zoneCloseBlueButton.Name = "zoneCloseBlueButton";
            this.zoneCloseBlueButton.Size = new System.Drawing.Size(56, 23);
            this.zoneCloseBlueButton.TabIndex = 18;
            this.zoneCloseBlueButton.Text = "Close";
            this.zoneCloseBlueButton.UseVisualStyleBackColor = true;
            this.zoneCloseBlueButton.Click += new System.EventHandler(this.zoneCloseBlueButton_Click);
            // 
            // zoneShowBlueButton
            // 
            this.zoneShowBlueButton.Location = new System.Drawing.Point(391, 40);
            this.zoneShowBlueButton.Name = "zoneShowBlueButton";
            this.zoneShowBlueButton.Size = new System.Drawing.Size(56, 23);
            this.zoneShowBlueButton.TabIndex = 17;
            this.zoneShowBlueButton.Text = "Show";
            this.zoneShowBlueButton.UseVisualStyleBackColor = true;
            this.zoneShowBlueButton.Click += new System.EventHandler(this.zoneShowBlueButton_Click);
            // 
            // zoneHideRedButton
            // 
            this.zoneHideRedButton.Location = new System.Drawing.Point(329, 127);
            this.zoneHideRedButton.Name = "zoneHideRedButton";
            this.zoneHideRedButton.Size = new System.Drawing.Size(56, 23);
            this.zoneHideRedButton.TabIndex = 16;
            this.zoneHideRedButton.Text = "Hide";
            this.zoneHideRedButton.UseVisualStyleBackColor = true;
            this.zoneHideRedButton.Click += new System.EventHandler(this.zoneHideRedButton_Click);
            // 
            // zoneActivateRedButton
            // 
            this.zoneActivateRedButton.Location = new System.Drawing.Point(329, 98);
            this.zoneActivateRedButton.Name = "zoneActivateRedButton";
            this.zoneActivateRedButton.Size = new System.Drawing.Size(56, 23);
            this.zoneActivateRedButton.TabIndex = 15;
            this.zoneActivateRedButton.Text = "Activate";
            this.zoneActivateRedButton.UseVisualStyleBackColor = true;
            this.zoneActivateRedButton.Click += new System.EventHandler(this.zoneActivateRedButton_Click);
            // 
            // zoneCloseRedButton
            // 
            this.zoneCloseRedButton.Location = new System.Drawing.Point(329, 69);
            this.zoneCloseRedButton.Name = "zoneCloseRedButton";
            this.zoneCloseRedButton.Size = new System.Drawing.Size(56, 23);
            this.zoneCloseRedButton.TabIndex = 14;
            this.zoneCloseRedButton.Text = "Close";
            this.zoneCloseRedButton.UseVisualStyleBackColor = true;
            this.zoneCloseRedButton.Click += new System.EventHandler(this.zoneCloseRedButton_Click);
            // 
            // zoneShowRedButton
            // 
            this.zoneShowRedButton.Location = new System.Drawing.Point(329, 40);
            this.zoneShowRedButton.Name = "zoneShowRedButton";
            this.zoneShowRedButton.Size = new System.Drawing.Size(56, 23);
            this.zoneShowRedButton.TabIndex = 13;
            this.zoneShowRedButton.Text = "Show";
            this.zoneShowRedButton.UseVisualStyleBackColor = true;
            this.zoneShowRedButton.Click += new System.EventHandler(this.zoneShowRedButton_Click);
            // 
            // zoneSmartPartInfoLeftZone
            // 
            this.zoneSmartPartInfoLeftZone.Description = "";
            this.zoneSmartPartInfoLeftZone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.zoneSmartPartInfoLeftZone.Title = "My Title";
            this.zoneSmartPartInfoLeftZone.ZoneName = "LeftZone";
            this.infoProvider.Items.Add(this.zoneSmartPartInfoLeftZone);
            // 
            // zoneSmartPartInfoRightZone
            // 
            this.zoneSmartPartInfoRightZone.Description = "";
            this.zoneSmartPartInfoRightZone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.zoneSmartPartInfoRightZone.Title = "My Title 2";
            this.zoneSmartPartInfoRightZone.ZoneName = "RightZone";
            this.infoProvider.Items.Add(this.zoneSmartPartInfoRightZone);
            // 
            // leftZoneRadioButton
            // 
            this.leftZoneRadioButton.AutoSize = true;
            this.leftZoneRadioButton.Checked = true;
            this.leftZoneRadioButton.Location = new System.Drawing.Point(331, 218);
            this.leftZoneRadioButton.Name = "leftZoneRadioButton";
            this.leftZoneRadioButton.Size = new System.Drawing.Size(69, 17);
            this.leftZoneRadioButton.TabIndex = 33;
            this.leftZoneRadioButton.TabStop = true;
            this.leftZoneRadioButton.Text = "Left zone";
            this.leftZoneRadioButton.UseVisualStyleBackColor = true;
            this.leftZoneRadioButton.CheckedChanged += new System.EventHandler(this.leftZoneRadioButton_CheckedChanged);
            // 
            // rightZoneRadioButton
            // 
            this.rightZoneRadioButton.AutoSize = true;
            this.rightZoneRadioButton.Location = new System.Drawing.Point(331, 236);
            this.rightZoneRadioButton.Name = "rightZoneRadioButton";
            this.rightZoneRadioButton.Size = new System.Drawing.Size(76, 17);
            this.rightZoneRadioButton.TabIndex = 34;
            this.rightZoneRadioButton.Text = "Right zone";
            this.rightZoneRadioButton.UseVisualStyleBackColor = true;
            this.rightZoneRadioButton.CheckedChanged += new System.EventHandler(this.rightZoneRadioButton_CheckedChanged);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(328, 189);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 36);
            this.label7.TabIndex = 35;
            this.label7.Text = "\'Show\' and \'Apply\' buttons apply to:";
            // 
            // zoneApplySmartPartInfoBlueButton
            // 
            this.zoneApplySmartPartInfoBlueButton.Location = new System.Drawing.Point(391, 156);
            this.zoneApplySmartPartInfoBlueButton.Name = "zoneApplySmartPartInfoBlueButton";
            this.zoneApplySmartPartInfoBlueButton.Size = new System.Drawing.Size(56, 23);
            this.zoneApplySmartPartInfoBlueButton.TabIndex = 37;
            this.zoneApplySmartPartInfoBlueButton.Text = "Apply";
            this.zoneApplySmartPartInfoBlueButton.UseVisualStyleBackColor = true;
            this.zoneApplySmartPartInfoBlueButton.Click += new System.EventHandler(this.zoneApplySmartPartInfoBlueButton_Click);
            // 
            // zoneApplySmartPartInfoRedButton
            // 
            this.zoneApplySmartPartInfoRedButton.Location = new System.Drawing.Point(329, 156);
            this.zoneApplySmartPartInfoRedButton.Name = "zoneApplySmartPartInfoRedButton";
            this.zoneApplySmartPartInfoRedButton.Size = new System.Drawing.Size(56, 23);
            this.zoneApplySmartPartInfoRedButton.TabIndex = 36;
            this.zoneApplySmartPartInfoRedButton.Text = "Apply";
            this.zoneApplySmartPartInfoRedButton.UseVisualStyleBackColor = true;
            this.zoneApplySmartPartInfoRedButton.Click += new System.EventHandler(this.zoneApplySmartPartInfoRedButton_Click);
            // 
            // showWorkItemDetailsButton
            // 
            this.showWorkItemDetailsButton.Location = new System.Drawing.Point(329, 276);
            this.showWorkItemDetailsButton.Name = "showWorkItemDetailsButton";
            this.showWorkItemDetailsButton.Size = new System.Drawing.Size(56, 23);
            this.showWorkItemDetailsButton.TabIndex = 38;
            this.showWorkItemDetailsButton.Text = "Details";
            this.showWorkItemDetailsButton.UseVisualStyleBackColor = true;
            this.showWorkItemDetailsButton.Click += new System.EventHandler(this.showWorkItemDetailsButton_Click);
            // 
            // ShellForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 311);
            this.Controls.Add(this.showWorkItemDetailsButton);
            this.Controls.Add(this.zoneApplySmartPartInfoBlueButton);
            this.Controls.Add(this.zoneApplySmartPartInfoRedButton);
            this.Controls.Add(this.rightZoneRadioButton);
            this.Controls.Add(this.leftZoneRadioButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.zoneHideBlueButton);
            this.Controls.Add(this.zoneActivateBlueButton);
            this.Controls.Add(this.zoneCloseBlueButton);
            this.Controls.Add(this.zoneShowBlueButton);
            this.Controls.Add(this.zoneHideRedButton);
            this.Controls.Add(this.zoneActivateRedButton);
            this.Controls.Add(this.zoneCloseRedButton);
            this.Controls.Add(this.zoneShowRedButton);
            this.Controls.Add(this.zoneWorkspace);
            this.Controls.Add(this.label7);
            this.Name = "ShellForm";
            this.Text = "Workspaces Demonstration";
            ((System.ComponentModel.ISupportInitialize)(this.zoneWorkspace)).EndInit();
            this.zoneWorkspace.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Practices.CompositeUI.WinForms.ZoneWorkspace zoneWorkspace;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button zoneHideBlueButton;
        private System.Windows.Forms.Button zoneActivateBlueButton;
        private System.Windows.Forms.Button zoneCloseBlueButton;
        private System.Windows.Forms.Button zoneShowBlueButton;
        private System.Windows.Forms.Button zoneHideRedButton;
        private System.Windows.Forms.Button zoneActivateRedButton;
        private System.Windows.Forms.Button zoneCloseRedButton;
        private System.Windows.Forms.Button zoneShowRedButton;
        private System.Windows.Forms.Panel leftZone;
        private Microsoft.Practices.CompositeUI.WinForms.ZoneSmartPartInfo zoneSmartPartInfoLeftZone;
        private System.Windows.Forms.Panel rightZone;
        private Microsoft.Practices.CompositeUI.WinForms.ZoneSmartPartInfo zoneSmartPartInfoRightZone;
        private System.Windows.Forms.RadioButton leftZoneRadioButton;
        private System.Windows.Forms.RadioButton rightZoneRadioButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button zoneApplySmartPartInfoBlueButton;
        private System.Windows.Forms.Button zoneApplySmartPartInfoRedButton;
        private Microsoft.Practices.CompositeUI.SmartParts.SmartPartInfoProvider infoProvider;
        private System.Windows.Forms.Button showWorkItemDetailsButton;

    }
}

