using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;

namespace CABMenus
{
    public partial class Shell : Form
    {
        public Shell()
        {
            InitializeComponent();
        }

        [CommandHandler("HelloCommand")]
        public void HelloHandler(object sender, EventArgs e)
        {
            MessageBox.Show("Hello world using CAB commands");
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello world using .NET events");
        }
        
    }
}