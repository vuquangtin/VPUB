using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;

namespace CABMenus
{
    public class Program : FormShellApplication<WorkItem, Shell>
    {
        [STAThread]
        static void Main()
        {
            new Program().Run();
        }
        protected override void AfterShellCreated()
        {
            base.AfterShellCreated();

            ToolStripItem toolStripItem = this.Shell.toolStripButton1;
            RootWorkItem.Commands["HelloCommand"].AddInvoker(toolStripItem, "Click");

            DisplayRootItemsCollection(RootWorkItem);
        }

        private void DisplayRootItemsCollection(WorkItem workItem)
        {
            System.Diagnostics.Debug.WriteLine("ITEMS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> coll = workItem.Items;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in coll)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }

            System.Diagnostics.Debug.WriteLine("COMMANDS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<Microsoft.Practices.CompositeUI.Commands.Command> cm = workItem.Commands;
            foreach (System.Collections.Generic.KeyValuePair<string, Microsoft.Practices.CompositeUI.Commands.Command> o in cm)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }
        }
    }
}