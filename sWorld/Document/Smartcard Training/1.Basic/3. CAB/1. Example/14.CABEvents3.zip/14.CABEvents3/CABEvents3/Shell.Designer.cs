namespace CABEvents3
{
    partial class Shell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cabEventFirerButton = new System.Windows.Forms.Button();
            this.addSubscriptionButton = new System.Windows.Forms.Button();
            this.removeSubscriptionButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cabEventFirerButton
            // 
            this.cabEventFirerButton.Location = new System.Drawing.Point(31, 32);
            this.cabEventFirerButton.Name = "cabEventFirerButton";
            this.cabEventFirerButton.Size = new System.Drawing.Size(110, 43);
            this.cabEventFirerButton.TabIndex = 0;
            this.cabEventFirerButton.Text = "Fire CAB Event";
            this.cabEventFirerButton.UseVisualStyleBackColor = true;
            this.cabEventFirerButton.Click += new System.EventHandler(this.cabEventFirerButton_Click);
            // 
            // addSubscriptionButton
            // 
            this.addSubscriptionButton.Enabled = false;
            this.addSubscriptionButton.Location = new System.Drawing.Point(167, 32);
            this.addSubscriptionButton.Name = "addSubscriptionButton";
            this.addSubscriptionButton.Size = new System.Drawing.Size(110, 43);
            this.addSubscriptionButton.TabIndex = 1;
            this.addSubscriptionButton.Text = "Add Subscription";
            this.addSubscriptionButton.UseVisualStyleBackColor = true;
            this.addSubscriptionButton.Click += new System.EventHandler(this.addSubscriptionButton_Click);
            // 
            // removeSubscriptionButton
            // 
            this.removeSubscriptionButton.Location = new System.Drawing.Point(300, 32);
            this.removeSubscriptionButton.Name = "removeSubscriptionButton";
            this.removeSubscriptionButton.Size = new System.Drawing.Size(110, 43);
            this.removeSubscriptionButton.TabIndex = 2;
            this.removeSubscriptionButton.Text = "Remove Subscription";
            this.removeSubscriptionButton.UseVisualStyleBackColor = true;
            this.removeSubscriptionButton.Click += new System.EventHandler(this.removeSubscriptionButton_Click);
            // 
            // Shell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 497);
            this.Controls.Add(this.removeSubscriptionButton);
            this.Controls.Add(this.addSubscriptionButton);
            this.Controls.Add(this.cabEventFirerButton);
            this.Name = "Shell";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Button cabEventFirerButton;
        public System.Windows.Forms.Button addSubscriptionButton;
        public System.Windows.Forms.Button removeSubscriptionButton;


    }
}

