using System;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.EventBroker;

namespace CABEvents3
{
    public class Subscriber
    {
        // The EventSubscription is set up in code in this example
        //[EventSubscription("MyEvent")]
        public void MyEventHandler(object sender, EventArgs e)
        {
            MessageBox.Show("Hello from the CAB event handler");
        }
    }
}
