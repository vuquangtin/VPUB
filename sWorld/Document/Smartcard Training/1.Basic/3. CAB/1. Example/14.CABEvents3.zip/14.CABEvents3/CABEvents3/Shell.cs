using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.EventBroker;

namespace CABEvents3
{
    public partial class Shell : Form
    {
        public Shell()
        {
            InitializeComponent();
        }

        private WorkItem rootWorkItem;
        [ServiceDependency]
        public WorkItem RootWorkItem
        {
            set
            {
                rootWorkItem = value;
            }
        }

        private void cabEventFirerButton_Click(object sender, EventArgs e)
        {
            rootWorkItem.EventTopics["MyEvent"].Fire(this, EventArgs.Empty, null, PublicationScope.Global);
        }

        private void addSubscriptionButton_Click(object sender, EventArgs e)
        {
            // The Subscriber object was created and added to the Items collection in AfterShellCreated
            Subscriber subscriber = (Subscriber)rootWorkItem.Items["Subscriber"];
            rootWorkItem.EventTopics["MyEvent"].AddSubscription(subscriber, "MyEventHandler", rootWorkItem, ThreadOption.Publisher);
            addSubscriptionButton.Enabled = false;
            removeSubscriptionButton.Enabled = true;
        }

        private void removeSubscriptionButton_Click(object sender, EventArgs e)
        {
            Subscriber subscriber = (Subscriber)rootWorkItem.Items["Subscriber"];
            rootWorkItem.EventTopics["MyEvent"].RemoveSubscription(subscriber, "MyEventHandler");
            addSubscriptionButton.Enabled = true;
            removeSubscriptionButton.Enabled = false;
        }
    }
}