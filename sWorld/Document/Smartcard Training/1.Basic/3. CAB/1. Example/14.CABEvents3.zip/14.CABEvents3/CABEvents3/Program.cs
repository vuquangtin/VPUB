using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;
using Microsoft.Practices.CompositeUI.EventBroker;

namespace CABEvents3
{
    public class Program : FormShellApplication<WorkItem, Shell>
    {
        [STAThread]
        static void Main()
        {
            new Program().Run();
        }
        protected override void AfterShellCreated()
        {
            base.AfterShellCreated();
            // Create a subscriber object and add a subscription to its MyEventHandler
            Subscriber subscriber = RootWorkItem.Items.AddNew<Subscriber>("Subscriber");
            RootWorkItem.EventTopics["MyEvent"].AddSubscription(subscriber, "MyEventHandler", RootWorkItem, ThreadOption.Publisher);
        }
    }
}