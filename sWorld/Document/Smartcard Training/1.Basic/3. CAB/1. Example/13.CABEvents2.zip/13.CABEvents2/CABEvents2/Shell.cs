using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.EventBroker;

namespace CABEvents2
{
    public partial class Shell : Form
    {
        public Shell()
        {
            InitializeComponent();
        }

        private WorkItem rootWorkItem;
        [ServiceDependency]
        public WorkItem RootWorkItem
        {
            set
            {
                rootWorkItem = value;
            }
        }

        // See Program.cs for comments on what this is doing
        private void fireGlobalButton_Click(object sender, EventArgs e)
        {
            rootWorkItem.EventTopics["MyEvent"].Fire(this, EventArgs.Empty, null, PublicationScope.Global);
        }

        private void fireWorkItemButton_Click(object sender, EventArgs e)
        {
            WorkItem childWorkItem1 = rootWorkItem.WorkItems["WorkItem1"].WorkItems["ChildWorkItem1"];
            rootWorkItem.EventTopics["MyEvent"].Fire(this, EventArgs.Empty, childWorkItem1, PublicationScope.WorkItem);
        }

        private void fireDescendantsButton_Click(object sender, EventArgs e)
        {
            WorkItem childWorkItem1 = rootWorkItem.WorkItems["WorkItem1"].WorkItems["ChildWorkItem1"];
            rootWorkItem.EventTopics["MyEvent"].Fire(this, EventArgs.Empty, childWorkItem1, PublicationScope.Descendants);
        }        
    }
}