using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;

namespace CABEvents2
{
    public class Program : FormShellApplication<WorkItem, Shell>
    {
        [STAThread]
        static void Main()
        {
            new Program().Run();
        }
        protected override void AfterShellCreated()
        {
            base.AfterShellCreated();

            /* 
             * We have a hierarchy of WorkItems as below:
             *          RootWorkItem
             *          |           |
             *      WorkItem1    WorkItem2
             *          |
             *      ChildWorkItem1
             *          |
             *     GrandChildWorkItem1
             * 
             * Each of these has a subscriber to our event "MyEvent" which displays an appropriate
             * message when the event is fired.
             * Our Shell form then has three buttons.  Each of these fires the event with the
             * ChildWorkItem1 passed in as the third parameter, but with different PublicationScope.
             * When you click the button you can see which EventSubscriptions get called in 
             * each case.
             */

            Subscriber subscriber;
            WorkItem workItem1 = RootWorkItem.WorkItems.AddNew<WorkItem>("WorkItem1");
            subscriber = workItem1.Items.AddNew<Subscriber>();
            subscriber.Message = "Hello from subscriber in WorkItem1";

            WorkItem childWorkItem1 = workItem1.WorkItems.AddNew<WorkItem>("ChildWorkItem1");
            subscriber = childWorkItem1.Items.AddNew<Subscriber>();
            subscriber.Message = "Hello from subscriber in ChildWorkItem1";

            WorkItem grandChildWorkItem1 = childWorkItem1.WorkItems.AddNew<WorkItem>("GrandChildWorkItem1");
            subscriber = grandChildWorkItem1.Items.AddNew<Subscriber>();
            subscriber.Message = "Hello from subscriber in GrandChildWorkItem1";

            WorkItem workItem2 = RootWorkItem.WorkItems.AddNew<WorkItem>("WorkItem2");
            subscriber = workItem2.Items.AddNew<Subscriber>();
            subscriber.Message = "Hello from subscriber in WorkItem2";


        }
    }
}