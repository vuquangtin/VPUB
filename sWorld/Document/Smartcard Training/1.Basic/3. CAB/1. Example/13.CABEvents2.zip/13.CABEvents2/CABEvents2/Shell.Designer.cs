namespace CABEvents2
{
    partial class Shell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fireGlobalButton = new System.Windows.Forms.Button();
            this.fireWorkItemButton = new System.Windows.Forms.Button();
            this.fireDescendantsButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // fireGlobalButton
            // 
            this.fireGlobalButton.Location = new System.Drawing.Point(31, 32);
            this.fireGlobalButton.Name = "fireGlobalButton";
            this.fireGlobalButton.Size = new System.Drawing.Size(110, 55);
            this.fireGlobalButton.TabIndex = 0;
            this.fireGlobalButton.Text = "Fire Global Event";
            this.fireGlobalButton.UseVisualStyleBackColor = true;
            this.fireGlobalButton.Click += new System.EventHandler(this.fireGlobalButton_Click);
            // 
            // fireWorkItemButton
            // 
            this.fireWorkItemButton.AutoEllipsis = true;
            this.fireWorkItemButton.Location = new System.Drawing.Point(172, 32);
            this.fireWorkItemButton.Name = "fireWorkItemButton";
            this.fireWorkItemButton.Size = new System.Drawing.Size(110, 55);
            this.fireWorkItemButton.TabIndex = 1;
            this.fireWorkItemButton.Text = "Fire Event on WorkItem only";
            this.fireWorkItemButton.UseVisualStyleBackColor = true;
            this.fireWorkItemButton.Click += new System.EventHandler(this.fireWorkItemButton_Click);
            // 
            // fireDescendantsButton
            // 
            this.fireDescendantsButton.Location = new System.Drawing.Point(314, 32);
            this.fireDescendantsButton.Name = "fireDescendantsButton";
            this.fireDescendantsButton.Size = new System.Drawing.Size(110, 55);
            this.fireDescendantsButton.TabIndex = 2;
            this.fireDescendantsButton.Text = "Fire Event on WorkItem and Descendants";
            this.fireDescendantsButton.UseVisualStyleBackColor = true;
            this.fireDescendantsButton.Click += new System.EventHandler(this.fireDescendantsButton_Click);
            // 
            // Shell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 163);
            this.Controls.Add(this.fireDescendantsButton);
            this.Controls.Add(this.fireWorkItemButton);
            this.Controls.Add(this.fireGlobalButton);
            this.Name = "Shell";
            this.Text = "CAB Events PublicationScope Example";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button fireGlobalButton;
        private System.Windows.Forms.Button fireWorkItemButton;
        private System.Windows.Forms.Button fireDescendantsButton;

    }
}

