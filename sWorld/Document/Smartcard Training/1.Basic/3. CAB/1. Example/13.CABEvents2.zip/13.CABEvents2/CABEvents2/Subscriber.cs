using System;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.EventBroker;

namespace CABEvents2
{
    // See Program.cs for comments on what this is doing
    public class Subscriber
    {
        private string message = "Not set";
        public string Message { get { return message; } set { message = value; } }

        [EventSubscription("MyEvent")]
        public void MyEventHandler(object sender, EventArgs e)
        {
            MessageBox.Show(message);
        }
    }
}
