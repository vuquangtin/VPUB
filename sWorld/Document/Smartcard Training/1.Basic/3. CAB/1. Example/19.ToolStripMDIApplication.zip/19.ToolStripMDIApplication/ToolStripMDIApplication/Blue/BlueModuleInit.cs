using Microsoft.Practices.CompositeUI;
using System.Windows.Forms;

namespace Blue
{
    public class BlueModuleInit : ModuleInit
    {
        private WorkItem parentWorkItem;

        [ServiceDependency]
        public WorkItem ParentWorkItem
        {
            set { parentWorkItem = value; }
        }

        private Form1 form;
        public override void Load()
        {
            // Code as before
            base.Load();
            Form shell = (Form)parentWorkItem.Items["Shell"];
            form = new Form1();
            form.MdiParent = shell;
            form.Show();

            // Create a new button, hook it up to an event handler, 
            // and add it to our ToolStrip by using the UIExtensionSite.
            ToolStripButton toolStripButton = new ToolStripButton("Show Blue Screen");
            toolStripButton.Click += new System.EventHandler(toolStripButton_Click);
            UIExtensionSite uiExtensionSite = parentWorkItem.UIExtensionSites["ShellToolStrip"];
            uiExtensionSite.Add<ToolStripButton>(toolStripButton);
        }

        void toolStripButton_Click(object sender, System.EventArgs e)
        {
            form.BringToFront();
        }
    }
}
