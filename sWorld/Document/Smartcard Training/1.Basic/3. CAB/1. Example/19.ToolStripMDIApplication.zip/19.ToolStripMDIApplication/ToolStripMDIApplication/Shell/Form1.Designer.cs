namespace Shell
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shellToolStrip = new System.Windows.Forms.ToolStrip();
            this.SuspendLayout();
            // 
            // shellToolStrip
            // 
            this.shellToolStrip.Location = new System.Drawing.Point(0, 0);
            this.shellToolStrip.Name = "shellToolStrip";
            this.shellToolStrip.Size = new System.Drawing.Size(442, 25);
            this.shellToolStrip.TabIndex = 0;
            this.shellToolStrip.Text = "toolStrip1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 355);
            this.Controls.Add(this.shellToolStrip);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.ToolStrip shellToolStrip;

    }
}

