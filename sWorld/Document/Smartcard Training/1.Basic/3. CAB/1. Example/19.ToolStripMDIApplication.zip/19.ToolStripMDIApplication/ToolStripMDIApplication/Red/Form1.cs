using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Red
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {

        }

//        public static void DebugDumpWorkItemCollections(Microsoft.Practices.CompositeUI.WorkItem workItem)
//        {
//#if(DEBUG)
//            System.Diagnostics.Debug.WriteLine("ITEMS:");
//            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> coll = workItem.Items;
//            foreach (System.Collections.Generic.KeyValuePair<string, object> o in coll)
//            {
//                System.Diagnostics.Debug.WriteLine(o.ToString());
//            }
//            System.Diagnostics.Debug.WriteLine("SERVICES:");
//            Microsoft.Practices.CompositeUI.Collections.ServiceCollection sc = workItem.Services;
//            foreach (System.Collections.Generic.KeyValuePair<System.Type, object> s in sc)
//            {
//                System.Diagnostics.Debug.WriteLine(s.ToString());
//            }
//            System.Diagnostics.Debug.WriteLine("SMARTPARTS:");
//            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> sp = workItem.SmartParts;
//            foreach (System.Collections.Generic.KeyValuePair<string, object> o in sp)
//            {
//                System.Diagnostics.Debug.WriteLine(o.ToString());
//            }
//            System.Diagnostics.Debug.WriteLine("COMMANDS:");
//            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<Microsoft.Practices.CompositeUI.Commands.Command> cm = workItem.Commands;
//            foreach (System.Collections.Generic.KeyValuePair<string, Microsoft.Practices.CompositeUI.Commands.Command> o in cm)
//            {
//                System.Diagnostics.Debug.WriteLine(o.ToString());
//            }
//            System.Diagnostics.Debug.WriteLine("EVENT TOPICS:");
//            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<Microsoft.Practices.CompositeUI.EventBroker.EventTopic> et = workItem.EventTopics;
//            foreach (System.Collections.Generic.KeyValuePair<string, Microsoft.Practices.CompositeUI.EventBroker.EventTopic> o in et)
//            {
//                Microsoft.Practices.CompositeUI.EventBroker.EventTopic eventTopic = o.Value;
//                System.Diagnostics.Debug.WriteLine(eventTopic.Name);
//            }
//            System.Diagnostics.Debug.WriteLine("WORKSPACES:");
//            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<Microsoft.Practices.CompositeUI.SmartParts.IWorkspace> ws = workItem.Workspaces;
//            foreach (System.Collections.Generic.KeyValuePair<string, Microsoft.Practices.CompositeUI.SmartParts.IWorkspace> o in ws)
//            {
//                Microsoft.Practices.CompositeUI.SmartParts.IWorkspace workspace = o.Value;
//                System.Diagnostics.Debug.WriteLine(o.ToString());
//                System.Diagnostics.Debug.WriteLine("\tSMARTPARTS:");
//                foreach (object x in workspace.SmartParts)
//                {
//                    System.Diagnostics.Debug.WriteLine("\t" + x.ToString());
//                }

//            }
//#endif
//        }
    }
}