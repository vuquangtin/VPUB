using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;

namespace Shell
{
    public class Program : FormShellApplication<WorkItem, Form1>
    {
        [STAThread]
        static void Main()
        {
            new Program().Run();
        }
        protected override void AfterShellCreated()
        {
            RootWorkItem.Services.AddNew<MyService, IMyService>();
            UseMyService();
            DisplayWorkItemCollections(RootWorkItem);
        }

        private void UseMyService()
        {
            IMyService service = RootWorkItem.Services.Get<IMyService>();
            System.Diagnostics.Debug.WriteLine(service.GetHello());
        }

        private void DisplayWorkItemCollections(WorkItem workItem)
        {
            System.Diagnostics.Debug.WriteLine("ITEMS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> coll = workItem.Items;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in coll)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }
            System.Diagnostics.Debug.WriteLine("SERVICES:");
            Microsoft.Practices.CompositeUI.Collections.ServiceCollection sc = workItem.Services;
            foreach (System.Collections.Generic.KeyValuePair<System.Type, object> s in sc)
            {
                System.Diagnostics.Debug.WriteLine(s.ToString());
            }
        }
    }
}