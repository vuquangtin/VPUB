using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.CompositeUI;

namespace Shell
{
    public class MyService : IMyService
    {
        public string GetHello()
        {
            return "Hello World";
        }
    }
}
