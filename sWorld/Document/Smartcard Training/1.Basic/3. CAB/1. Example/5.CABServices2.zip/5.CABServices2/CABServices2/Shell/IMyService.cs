using System;
using System.Collections.Generic;
using System.Text;

namespace Shell
{
    public interface IMyService
    {
        string GetHello();
    }
}
