using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace Shell
{
    public partial class ShellForm : Form, ISmartPartInfoProvider
    {
        private WorkItem rootWorkItem;
        [ServiceDependency]
        public WorkItem WorkItem { set { rootWorkItem = value; } }

        public ShellForm()
        {
            InitializeComponent();
        }

        RedSmartPart redSmartPart = new RedSmartPart();
        BlueSmartPart blueSmartPart = new BlueSmartPart();


        public void DebugDumpWorkItemCollections(Microsoft.Practices.CompositeUI.WorkItem workItem)
        {
#if(DEBUG)
            System.Diagnostics.Debug.WriteLine("ITEMS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> coll = workItem.Items;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in coll)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }
            System.Diagnostics.Debug.WriteLine("SMARTPARTS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> sp = workItem.SmartParts;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in sp)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }
            System.Diagnostics.Debug.WriteLine("WORKSPACES:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<Microsoft.Practices.CompositeUI.SmartParts.IWorkspace> ws = workItem.Workspaces;
            foreach (System.Collections.Generic.KeyValuePair<string, Microsoft.Practices.CompositeUI.SmartParts.IWorkspace> o in ws)
            {
                Microsoft.Practices.CompositeUI.SmartParts.IWorkspace workspace = o.Value;
                System.Diagnostics.Debug.WriteLine(o.ToString());
                System.Diagnostics.Debug.WriteLine("\tSMARTPARTS:");
                foreach (object x in workspace.SmartParts)
                {
                    System.Diagnostics.Debug.WriteLine("\t" + x.ToString());
                }

            }
#endif
        }

        #region TabWorkspace button handlers

        private void tabShowRedButton_Click(object sender, EventArgs e)
        {
            this.tabWorkspace.Show(redSmartPart, this.redTabSmartPartInfo);
        }

        private void tabShowBlueButton_Click(object sender, EventArgs e)
        {
            this.tabWorkspace.Show(blueSmartPart, this.blueTabSmartPartInfo);
        }

        private void tabCloseRedButton_Click(object sender, EventArgs e)
        {
            this.tabWorkspace.Close(redSmartPart);
        }

        private void tabCloseBlueButton_Click(object sender, EventArgs e)
        {
            this.tabWorkspace.Close(blueSmartPart);
        }

        private void tabActivateRedButton_Click(object sender, EventArgs e)
        {
            this.tabWorkspace.Activate(redSmartPart);
        }

        private void tabActivateBlueButton_Click(object sender, EventArgs e)
        {
            this.tabWorkspace.Activate(blueSmartPart);
        }

        private void tabHideRedButton_Click(object sender, EventArgs e)
        {
            this.tabWorkspace.Hide(redSmartPart);
        }

        private void tabHideBlueButton_Click(object sender, EventArgs e)
        {
            this.tabWorkspace.Hide(blueSmartPart);
        }

        private void tabApplySmartPartInfoRedButton_Click(object sender, EventArgs e)
        {
            TabSmartPartInfo tabSmartPartInfo = new TabSmartPartInfo();
            tabSmartPartInfo.Title = newTabNameTextBox.Text;
            this.tabWorkspace.ApplySmartPartInfo(redSmartPart, tabSmartPartInfo);
        }

        private void tabApplySmartPartInfoBlueButton_Click(object sender, EventArgs e)
        {
            TabSmartPartInfo tabSmartPartInfo = new TabSmartPartInfo();
            tabSmartPartInfo.Title = newTabNameTextBox.Text;
            this.tabWorkspace.ApplySmartPartInfo(blueSmartPart, tabSmartPartInfo);
        }

        #endregion

        public Microsoft.Practices.CompositeUI.SmartParts.ISmartPartInfo GetSmartPartInfo(Type smartPartInfoType)
        {
            // Implement ISmartPartInfoProvider in the containing smart part. Required in order for contained smart part infos to work.
            Microsoft.Practices.CompositeUI.SmartParts.ISmartPartInfoProvider ensureProvider = this;
            return this.infoProvider.GetSmartPartInfo(smartPartInfoType);

        }

    }
}