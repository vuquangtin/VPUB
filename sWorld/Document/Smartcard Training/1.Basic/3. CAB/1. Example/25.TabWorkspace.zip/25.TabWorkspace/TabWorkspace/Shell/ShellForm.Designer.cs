namespace Shell
{
    partial class ShellForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabWorkspace = new Microsoft.Practices.CompositeUI.WinForms.TabWorkspace();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabHideBlueButton = new System.Windows.Forms.Button();
            this.tabActivateBlueButton = new System.Windows.Forms.Button();
            this.tabCloseBlueButton = new System.Windows.Forms.Button();
            this.tabShowBlueButton = new System.Windows.Forms.Button();
            this.tabHideRedButton = new System.Windows.Forms.Button();
            this.tabActivateRedButton = new System.Windows.Forms.Button();
            this.tabCloseRedButton = new System.Windows.Forms.Button();
            this.tabShowRedButton = new System.Windows.Forms.Button();
            this.infoProvider = new Microsoft.Practices.CompositeUI.SmartParts.SmartPartInfoProvider();
            this.redTabSmartPartInfo = new Microsoft.Practices.CompositeUI.WinForms.TabSmartPartInfo();
            this.blueTabSmartPartInfo = new Microsoft.Practices.CompositeUI.WinForms.TabSmartPartInfo();
            this.label7 = new System.Windows.Forms.Label();
            this.tabApplySmartPartInfoBlueButton = new System.Windows.Forms.Button();
            this.tabApplySmartPartInfoRedButton = new System.Windows.Forms.Button();
            this.newTabNameTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tabWorkspace
            // 
            this.tabWorkspace.Location = new System.Drawing.Point(12, 4);
            this.tabWorkspace.Name = "tabWorkspace";
            this.tabWorkspace.SelectedIndex = 0;
            this.tabWorkspace.Size = new System.Drawing.Size(300, 230);
            this.tabWorkspace.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(387, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 30);
            this.label3.TabIndex = 22;
            this.label3.Text = "Blue SmartPart";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(325, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 30);
            this.label4.TabIndex = 21;
            this.label4.Text = "Red SmartPart";
            // 
            // tabHideBlueButton
            // 
            this.tabHideBlueButton.Location = new System.Drawing.Point(390, 124);
            this.tabHideBlueButton.Name = "tabHideBlueButton";
            this.tabHideBlueButton.Size = new System.Drawing.Size(56, 23);
            this.tabHideBlueButton.TabIndex = 20;
            this.tabHideBlueButton.Text = "Hide";
            this.tabHideBlueButton.UseVisualStyleBackColor = true;
            this.tabHideBlueButton.Click += new System.EventHandler(this.tabHideBlueButton_Click);
            // 
            // tabActivateBlueButton
            // 
            this.tabActivateBlueButton.Location = new System.Drawing.Point(390, 95);
            this.tabActivateBlueButton.Name = "tabActivateBlueButton";
            this.tabActivateBlueButton.Size = new System.Drawing.Size(56, 23);
            this.tabActivateBlueButton.TabIndex = 19;
            this.tabActivateBlueButton.Text = "Activate";
            this.tabActivateBlueButton.UseVisualStyleBackColor = true;
            this.tabActivateBlueButton.Click += new System.EventHandler(this.tabActivateBlueButton_Click);
            // 
            // tabCloseBlueButton
            // 
            this.tabCloseBlueButton.Location = new System.Drawing.Point(390, 66);
            this.tabCloseBlueButton.Name = "tabCloseBlueButton";
            this.tabCloseBlueButton.Size = new System.Drawing.Size(56, 23);
            this.tabCloseBlueButton.TabIndex = 18;
            this.tabCloseBlueButton.Text = "Close";
            this.tabCloseBlueButton.UseVisualStyleBackColor = true;
            this.tabCloseBlueButton.Click += new System.EventHandler(this.tabCloseBlueButton_Click);
            // 
            // tabShowBlueButton
            // 
            this.tabShowBlueButton.Location = new System.Drawing.Point(390, 37);
            this.tabShowBlueButton.Name = "tabShowBlueButton";
            this.tabShowBlueButton.Size = new System.Drawing.Size(56, 23);
            this.tabShowBlueButton.TabIndex = 17;
            this.tabShowBlueButton.Text = "Show";
            this.tabShowBlueButton.UseVisualStyleBackColor = true;
            this.tabShowBlueButton.Click += new System.EventHandler(this.tabShowBlueButton_Click);
            // 
            // tabHideRedButton
            // 
            this.tabHideRedButton.Location = new System.Drawing.Point(328, 124);
            this.tabHideRedButton.Name = "tabHideRedButton";
            this.tabHideRedButton.Size = new System.Drawing.Size(56, 23);
            this.tabHideRedButton.TabIndex = 16;
            this.tabHideRedButton.Text = "Hide";
            this.tabHideRedButton.UseVisualStyleBackColor = true;
            this.tabHideRedButton.Click += new System.EventHandler(this.tabHideRedButton_Click);
            // 
            // tabActivateRedButton
            // 
            this.tabActivateRedButton.Location = new System.Drawing.Point(328, 95);
            this.tabActivateRedButton.Name = "tabActivateRedButton";
            this.tabActivateRedButton.Size = new System.Drawing.Size(56, 23);
            this.tabActivateRedButton.TabIndex = 15;
            this.tabActivateRedButton.Text = "Activate";
            this.tabActivateRedButton.UseVisualStyleBackColor = true;
            this.tabActivateRedButton.Click += new System.EventHandler(this.tabActivateRedButton_Click);
            // 
            // tabCloseRedButton
            // 
            this.tabCloseRedButton.Location = new System.Drawing.Point(328, 66);
            this.tabCloseRedButton.Name = "tabCloseRedButton";
            this.tabCloseRedButton.Size = new System.Drawing.Size(56, 23);
            this.tabCloseRedButton.TabIndex = 14;
            this.tabCloseRedButton.Text = "Close";
            this.tabCloseRedButton.UseVisualStyleBackColor = true;
            this.tabCloseRedButton.Click += new System.EventHandler(this.tabCloseRedButton_Click);
            // 
            // tabShowRedButton
            // 
            this.tabShowRedButton.Location = new System.Drawing.Point(328, 37);
            this.tabShowRedButton.Name = "tabShowRedButton";
            this.tabShowRedButton.Size = new System.Drawing.Size(56, 23);
            this.tabShowRedButton.TabIndex = 13;
            this.tabShowRedButton.Text = "Show";
            this.tabShowRedButton.UseVisualStyleBackColor = true;
            this.tabShowRedButton.Click += new System.EventHandler(this.tabShowRedButton_Click);
            // 
            // redTabSmartPartInfo
            // 
            this.redTabSmartPartInfo.Description = "";
            this.redTabSmartPartInfo.Position = Microsoft.Practices.CompositeUI.WinForms.TabPosition.Beginning;
            this.redTabSmartPartInfo.Title = "Red Tab";
            this.infoProvider.Items.Add(this.redTabSmartPartInfo);
            // 
            // blueTabSmartPartInfo
            // 
            this.blueTabSmartPartInfo.Description = "";
            this.blueTabSmartPartInfo.Title = "Blue Tab";
            this.infoProvider.Items.Add(this.blueTabSmartPartInfo);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(328, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 13);
            this.label7.TabIndex = 35;
            this.label7.Text = "New tab name:";
            // 
            // tabApplySmartPartInfoBlueButton
            // 
            this.tabApplySmartPartInfoBlueButton.Location = new System.Drawing.Point(390, 211);
            this.tabApplySmartPartInfoBlueButton.Name = "tabApplySmartPartInfoBlueButton";
            this.tabApplySmartPartInfoBlueButton.Size = new System.Drawing.Size(56, 23);
            this.tabApplySmartPartInfoBlueButton.TabIndex = 37;
            this.tabApplySmartPartInfoBlueButton.Text = "Apply";
            this.tabApplySmartPartInfoBlueButton.UseVisualStyleBackColor = true;
            this.tabApplySmartPartInfoBlueButton.Click += new System.EventHandler(this.tabApplySmartPartInfoBlueButton_Click);
            // 
            // tabApplySmartPartInfoRedButton
            // 
            this.tabApplySmartPartInfoRedButton.Location = new System.Drawing.Point(328, 211);
            this.tabApplySmartPartInfoRedButton.Name = "tabApplySmartPartInfoRedButton";
            this.tabApplySmartPartInfoRedButton.Size = new System.Drawing.Size(56, 23);
            this.tabApplySmartPartInfoRedButton.TabIndex = 36;
            this.tabApplySmartPartInfoRedButton.Text = "Apply";
            this.tabApplySmartPartInfoRedButton.UseVisualStyleBackColor = true;
            this.tabApplySmartPartInfoRedButton.Click += new System.EventHandler(this.tabApplySmartPartInfoRedButton_Click);
            // 
            // newTabNameTextBox
            // 
            this.newTabNameTextBox.Location = new System.Drawing.Point(331, 185);
            this.newTabNameTextBox.Name = "newTabNameTextBox";
            this.newTabNameTextBox.Size = new System.Drawing.Size(115, 20);
            this.newTabNameTextBox.TabIndex = 38;
            // 
            // ShellForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 253);
            this.Controls.Add(this.newTabNameTextBox);
            this.Controls.Add(this.tabApplySmartPartInfoBlueButton);
            this.Controls.Add(this.tabApplySmartPartInfoRedButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tabHideBlueButton);
            this.Controls.Add(this.tabActivateBlueButton);
            this.Controls.Add(this.tabCloseBlueButton);
            this.Controls.Add(this.tabShowBlueButton);
            this.Controls.Add(this.tabHideRedButton);
            this.Controls.Add(this.tabActivateRedButton);
            this.Controls.Add(this.tabCloseRedButton);
            this.Controls.Add(this.tabShowRedButton);
            this.Controls.Add(this.tabWorkspace);
            this.Name = "ShellForm";
            this.Text = "Workspaces Demonstration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Practices.CompositeUI.WinForms.TabWorkspace tabWorkspace;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button tabHideBlueButton;
        private System.Windows.Forms.Button tabActivateBlueButton;
        private System.Windows.Forms.Button tabCloseBlueButton;
        private System.Windows.Forms.Button tabShowBlueButton;
        private System.Windows.Forms.Button tabHideRedButton;
        private System.Windows.Forms.Button tabActivateRedButton;
        private System.Windows.Forms.Button tabCloseRedButton;
        private System.Windows.Forms.Button tabShowRedButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button tabApplySmartPartInfoBlueButton;
        private System.Windows.Forms.Button tabApplySmartPartInfoRedButton;
        private Microsoft.Practices.CompositeUI.WinForms.TabSmartPartInfo redTabSmartPartInfo;
        private Microsoft.Practices.CompositeUI.WinForms.TabSmartPartInfo blueTabSmartPartInfo;
        private Microsoft.Practices.CompositeUI.SmartParts.SmartPartInfoProvider infoProvider;
        private System.Windows.Forms.TextBox newTabNameTextBox;

    }
}

