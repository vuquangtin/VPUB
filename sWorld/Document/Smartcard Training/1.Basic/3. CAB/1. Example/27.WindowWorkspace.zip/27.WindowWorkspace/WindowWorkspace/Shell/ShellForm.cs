using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace Shell
{
    public partial class ShellForm : Form, ISmartPartInfoProvider
    {
        private WorkItem rootWorkItem;
        [ServiceDependency]
        public WorkItem WorkItem { set { rootWorkItem = value; } }
        WindowWorkspace windowWorkspace; 

        public ShellForm()
        {
            InitializeComponent();
            windowWorkspace = new WindowWorkspace(this);
        }

        RedSmartPart redSmartPart = new RedSmartPart();
        BlueSmartPart blueSmartPart = new BlueSmartPart();

        #region mdiWorkspace button handlers

        private void windowShowRedButton_Click(object sender, EventArgs e)
        {
            this.windowWorkspace.Show(redSmartPart, this.redWindowSmartPartInfo);
        }

        private void windowShowBlueButton_Click(object sender, EventArgs e)
        {
            this.windowWorkspace.Show(blueSmartPart, this.blueWindowSmartPartInfo);
        }

        private void windowCloseRedButton_Click(object sender, EventArgs e)
        {
            this.windowWorkspace.Close(redSmartPart);
        }

        private void windowCloseBlueButton_Click(object sender, EventArgs e)
        {
            this.windowWorkspace.Close(blueSmartPart);
        }

        private void windowActivateRedButton_Click(object sender, EventArgs e)
        {
            this.windowWorkspace.Activate(redSmartPart);
        }

        private void windowActivateBlueButton_Click(object sender, EventArgs e)
        {
            this.windowWorkspace.Activate(blueSmartPart);
        }

        private void windowHideRedButton_Click(object sender, EventArgs e)
        {
            this.windowWorkspace.Hide(redSmartPart);
        }

        private void windowHideBlueButton_Click(object sender, EventArgs e)
        {
            this.windowWorkspace.Hide(blueSmartPart);
        }

        private void windowApplySmartPartInfoRedButton_Click(object sender, EventArgs e)
        {
            redWindowSmartPartInfo.Title = newNameTextBox.Text;
            this.windowWorkspace.ApplySmartPartInfo(redSmartPart, redWindowSmartPartInfo);
        }

        private void windowApplySmartPartInfoBlueButton_Click(object sender, EventArgs e)
        {
            blueWindowSmartPartInfo.Title = newNameTextBox.Text;
            this.windowWorkspace.ApplySmartPartInfo(blueSmartPart, blueWindowSmartPartInfo);
        }

        #endregion

        public Microsoft.Practices.CompositeUI.SmartParts.ISmartPartInfo GetSmartPartInfo(Type smartPartInfoType)
        {
            // Implement ISmartPartInfoProvider in the containing smart part. Required in order for contained smart part infos to work.
            Microsoft.Practices.CompositeUI.SmartParts.ISmartPartInfoProvider ensureProvider = this;
            return this.infoProvider.GetSmartPartInfo(smartPartInfoType);

        }

    }
}