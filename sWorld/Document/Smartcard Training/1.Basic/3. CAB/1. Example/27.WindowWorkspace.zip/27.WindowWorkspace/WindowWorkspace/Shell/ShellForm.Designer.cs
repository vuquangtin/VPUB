namespace Shell
{
    partial class ShellForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShellForm));
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.mdiHideBlueButton = new System.Windows.Forms.Button();
            this.mdiActivateBlueButton = new System.Windows.Forms.Button();
            this.mdiCloseBlueButton = new System.Windows.Forms.Button();
            this.mdiShowBlueButton = new System.Windows.Forms.Button();
            this.mdiHideRedButton = new System.Windows.Forms.Button();
            this.mdiActivateRedButton = new System.Windows.Forms.Button();
            this.mdiCloseRedButton = new System.Windows.Forms.Button();
            this.mdiShowRedButton = new System.Windows.Forms.Button();
            this.infoProvider = new Microsoft.Practices.CompositeUI.SmartParts.SmartPartInfoProvider();
            this.redWindowSmartPartInfo = new Microsoft.Practices.CompositeUI.WinForms.WindowSmartPartInfo();
            this.blueWindowSmartPartInfo = new Microsoft.Practices.CompositeUI.WinForms.WindowSmartPartInfo();
            this.label7 = new System.Windows.Forms.Label();
            this.mdiApplySmartPartInfoBlueButton = new System.Windows.Forms.Button();
            this.mdiApplySmartPartInfoRedButton = new System.Windows.Forms.Button();
            this.newNameTextBox = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(74, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 30);
            this.label3.TabIndex = 22;
            this.label3.Text = "Blue SmartPart";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(12, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 30);
            this.label4.TabIndex = 21;
            this.label4.Text = "Red SmartPart";
            // 
            // mdiHideBlueButton
            // 
            this.mdiHideBlueButton.Location = new System.Drawing.Point(77, 128);
            this.mdiHideBlueButton.Name = "mdiHideBlueButton";
            this.mdiHideBlueButton.Size = new System.Drawing.Size(56, 23);
            this.mdiHideBlueButton.TabIndex = 20;
            this.mdiHideBlueButton.Text = "Hide";
            this.mdiHideBlueButton.UseVisualStyleBackColor = true;
            this.mdiHideBlueButton.Click += new System.EventHandler(this.windowHideBlueButton_Click);
            // 
            // mdiActivateBlueButton
            // 
            this.mdiActivateBlueButton.Location = new System.Drawing.Point(77, 99);
            this.mdiActivateBlueButton.Name = "mdiActivateBlueButton";
            this.mdiActivateBlueButton.Size = new System.Drawing.Size(56, 23);
            this.mdiActivateBlueButton.TabIndex = 19;
            this.mdiActivateBlueButton.Text = "Activate";
            this.mdiActivateBlueButton.UseVisualStyleBackColor = true;
            this.mdiActivateBlueButton.Click += new System.EventHandler(this.windowActivateBlueButton_Click);
            // 
            // mdiCloseBlueButton
            // 
            this.mdiCloseBlueButton.Location = new System.Drawing.Point(77, 70);
            this.mdiCloseBlueButton.Name = "mdiCloseBlueButton";
            this.mdiCloseBlueButton.Size = new System.Drawing.Size(56, 23);
            this.mdiCloseBlueButton.TabIndex = 18;
            this.mdiCloseBlueButton.Text = "Close";
            this.mdiCloseBlueButton.UseVisualStyleBackColor = true;
            this.mdiCloseBlueButton.Click += new System.EventHandler(this.windowCloseBlueButton_Click);
            // 
            // mdiShowBlueButton
            // 
            this.mdiShowBlueButton.Location = new System.Drawing.Point(77, 41);
            this.mdiShowBlueButton.Name = "mdiShowBlueButton";
            this.mdiShowBlueButton.Size = new System.Drawing.Size(56, 23);
            this.mdiShowBlueButton.TabIndex = 17;
            this.mdiShowBlueButton.Text = "Show";
            this.mdiShowBlueButton.UseVisualStyleBackColor = true;
            this.mdiShowBlueButton.Click += new System.EventHandler(this.windowShowBlueButton_Click);
            // 
            // mdiHideRedButton
            // 
            this.mdiHideRedButton.Location = new System.Drawing.Point(15, 128);
            this.mdiHideRedButton.Name = "mdiHideRedButton";
            this.mdiHideRedButton.Size = new System.Drawing.Size(56, 23);
            this.mdiHideRedButton.TabIndex = 16;
            this.mdiHideRedButton.Text = "Hide";
            this.mdiHideRedButton.UseVisualStyleBackColor = true;
            this.mdiHideRedButton.Click += new System.EventHandler(this.windowHideRedButton_Click);
            // 
            // mdiActivateRedButton
            // 
            this.mdiActivateRedButton.Location = new System.Drawing.Point(15, 99);
            this.mdiActivateRedButton.Name = "mdiActivateRedButton";
            this.mdiActivateRedButton.Size = new System.Drawing.Size(56, 23);
            this.mdiActivateRedButton.TabIndex = 15;
            this.mdiActivateRedButton.Text = "Activate";
            this.mdiActivateRedButton.UseVisualStyleBackColor = true;
            this.mdiActivateRedButton.Click += new System.EventHandler(this.windowActivateRedButton_Click);
            // 
            // mdiCloseRedButton
            // 
            this.mdiCloseRedButton.Location = new System.Drawing.Point(15, 70);
            this.mdiCloseRedButton.Name = "mdiCloseRedButton";
            this.mdiCloseRedButton.Size = new System.Drawing.Size(56, 23);
            this.mdiCloseRedButton.TabIndex = 14;
            this.mdiCloseRedButton.Text = "Close";
            this.mdiCloseRedButton.UseVisualStyleBackColor = true;
            this.mdiCloseRedButton.Click += new System.EventHandler(this.windowCloseRedButton_Click);
            // 
            // mdiShowRedButton
            // 
            this.mdiShowRedButton.Location = new System.Drawing.Point(15, 41);
            this.mdiShowRedButton.Name = "mdiShowRedButton";
            this.mdiShowRedButton.Size = new System.Drawing.Size(56, 23);
            this.mdiShowRedButton.TabIndex = 13;
            this.mdiShowRedButton.Text = "Show";
            this.mdiShowRedButton.UseVisualStyleBackColor = true;
            this.mdiShowRedButton.Click += new System.EventHandler(this.windowShowRedButton_Click);
            // 
            // redWindowSmartPartInfo
            // 
            this.redWindowSmartPartInfo.Description = "";
            this.redWindowSmartPartInfo.Location = new System.Drawing.Point(10, 10);
            this.redWindowSmartPartInfo.MaximizeBox = false;
            this.redWindowSmartPartInfo.MinimizeBox = false;
            this.redWindowSmartPartInfo.Title = "Red Window Title";
            this.infoProvider.Items.Add(this.redWindowSmartPartInfo);
            // 
            // blueWindowSmartPartInfo
            // 
            this.blueWindowSmartPartInfo.Description = "";
            this.blueWindowSmartPartInfo.Icon = ((System.Drawing.Icon)(resources.GetObject("blueWindowSmartPartInfo.Icon")));
            this.blueWindowSmartPartInfo.Location = new System.Drawing.Point(0, 0);
            this.blueWindowSmartPartInfo.MaximizeBox = false;
            this.blueWindowSmartPartInfo.Title = "";
            this.infoProvider.Items.Add(this.blueWindowSmartPartInfo);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 35;
            this.label7.Text = "New child name:";
            // 
            // mdiApplySmartPartInfoBlueButton
            // 
            this.mdiApplySmartPartInfoBlueButton.Location = new System.Drawing.Point(77, 215);
            this.mdiApplySmartPartInfoBlueButton.Name = "mdiApplySmartPartInfoBlueButton";
            this.mdiApplySmartPartInfoBlueButton.Size = new System.Drawing.Size(56, 23);
            this.mdiApplySmartPartInfoBlueButton.TabIndex = 37;
            this.mdiApplySmartPartInfoBlueButton.Text = "Apply";
            this.mdiApplySmartPartInfoBlueButton.UseVisualStyleBackColor = true;
            this.mdiApplySmartPartInfoBlueButton.Click += new System.EventHandler(this.windowApplySmartPartInfoBlueButton_Click);
            // 
            // mdiApplySmartPartInfoRedButton
            // 
            this.mdiApplySmartPartInfoRedButton.Location = new System.Drawing.Point(15, 215);
            this.mdiApplySmartPartInfoRedButton.Name = "mdiApplySmartPartInfoRedButton";
            this.mdiApplySmartPartInfoRedButton.Size = new System.Drawing.Size(56, 23);
            this.mdiApplySmartPartInfoRedButton.TabIndex = 36;
            this.mdiApplySmartPartInfoRedButton.Text = "Apply";
            this.mdiApplySmartPartInfoRedButton.UseVisualStyleBackColor = true;
            this.mdiApplySmartPartInfoRedButton.Click += new System.EventHandler(this.windowApplySmartPartInfoRedButton_Click);
            // 
            // newNameTextBox
            // 
            this.newNameTextBox.Location = new System.Drawing.Point(18, 189);
            this.newNameTextBox.Name = "newNameTextBox";
            this.newNameTextBox.Size = new System.Drawing.Size(115, 20);
            this.newNameTextBox.TabIndex = 38;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.mdiShowRedButton);
            this.panel1.Controls.Add(this.newNameTextBox);
            this.panel1.Controls.Add(this.mdiCloseRedButton);
            this.panel1.Controls.Add(this.mdiApplySmartPartInfoBlueButton);
            this.panel1.Controls.Add(this.mdiActivateRedButton);
            this.panel1.Controls.Add(this.mdiApplySmartPartInfoRedButton);
            this.panel1.Controls.Add(this.mdiHideRedButton);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.mdiShowBlueButton);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.mdiCloseBlueButton);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.mdiActivateBlueButton);
            this.panel1.Controls.Add(this.mdiHideBlueButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(158, 253);
            this.panel1.TabIndex = 39;
            // 
            // ShellForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(158, 253);
            this.Controls.Add(this.panel1);
            this.Name = "ShellForm";
            this.Text = "Workspaces";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button mdiHideBlueButton;
        private System.Windows.Forms.Button mdiActivateBlueButton;
        private System.Windows.Forms.Button mdiCloseBlueButton;
        private System.Windows.Forms.Button mdiShowBlueButton;
        private System.Windows.Forms.Button mdiHideRedButton;
        private System.Windows.Forms.Button mdiActivateRedButton;
        private System.Windows.Forms.Button mdiCloseRedButton;
        private System.Windows.Forms.Button mdiShowRedButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button mdiApplySmartPartInfoBlueButton;
        private System.Windows.Forms.Button mdiApplySmartPartInfoRedButton;
        private System.Windows.Forms.TextBox newNameTextBox;
        private System.Windows.Forms.Panel panel1;
        private Microsoft.Practices.CompositeUI.WinForms.WindowSmartPartInfo redWindowSmartPartInfo;
        private Microsoft.Practices.CompositeUI.WinForms.WindowSmartPartInfo blueWindowSmartPartInfo;
        private Microsoft.Practices.CompositeUI.SmartParts.SmartPartInfoProvider infoProvider;

    }
}

