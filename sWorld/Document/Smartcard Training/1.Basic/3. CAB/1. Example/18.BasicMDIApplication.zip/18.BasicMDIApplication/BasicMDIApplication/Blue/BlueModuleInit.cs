using Microsoft.Practices.CompositeUI;
using System.Windows.Forms;

namespace Blue
{
    public class BlueModuleInit : ModuleInit
    {
        private WorkItem parentWorkItem;

        [ServiceDependency]
        public WorkItem ParentWorkItem
        {
            set { parentWorkItem = value; }
        }

        public override void Load()
        {
            base.Load();
            Form shell = (Form)parentWorkItem.Items["Shell"];
            Form1 form = new Form1();
            form.MdiParent = shell;
            form.Show();
        }
    }
}
