using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace Shell
{
    public class Program : FormShellApplication<WorkItem, Form1>
    {
        [STAThread]
        static void Main()
        {
            new Program().Run();
        }
        protected override void AfterShellCreated()
        {
            base.AfterShellCreated();
            DebugDumpWorkItemCollections(RootWorkItem);
        }

        public static void DebugDumpWorkItemCollections(Microsoft.Practices.CompositeUI.WorkItem workItem)
        {
#if(DEBUG)
            System.Diagnostics.Debug.WriteLine("ITEMS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> coll = workItem.Items;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in coll)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }
            System.Diagnostics.Debug.WriteLine("SMARTPARTS:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<object> sp = workItem.SmartParts;
            foreach (System.Collections.Generic.KeyValuePair<string, object> o in sp)
            {
                System.Diagnostics.Debug.WriteLine(o.ToString());
            }
            System.Diagnostics.Debug.WriteLine("WORKSPACES:");
            Microsoft.Practices.CompositeUI.Collections.ManagedObjectCollection<Microsoft.Practices.CompositeUI.SmartParts.IWorkspace> ws = workItem.Workspaces;
            foreach (System.Collections.Generic.KeyValuePair<string, Microsoft.Practices.CompositeUI.SmartParts.IWorkspace> o in ws)
            {
                Microsoft.Practices.CompositeUI.SmartParts.IWorkspace workspace = o.Value;
                System.Diagnostics.Debug.WriteLine(o.ToString());
                System.Diagnostics.Debug.WriteLine("\tSMARTPARTS:");
                foreach (object x in workspace.SmartParts)
                {
                    System.Diagnostics.Debug.WriteLine("\t" + x.ToString());
                }

            }
#endif
        }
    }

    [SmartPart]
    internal class TestClass {}
}