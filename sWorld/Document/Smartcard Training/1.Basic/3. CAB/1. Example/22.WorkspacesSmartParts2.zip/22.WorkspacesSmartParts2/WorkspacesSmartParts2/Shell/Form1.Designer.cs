namespace Shell
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.deckWorkspace1 = new Microsoft.Practices.CompositeUI.WinForms.DeckWorkspace();
            this.userControl11 = new Shell.SmartPartUserControl();
            this.userControl21 = new Shell.NormalUserControl();
            this.SuspendLayout();
            // 
            // deckWorkspace1
            // 
            this.deckWorkspace1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.deckWorkspace1.Location = new System.Drawing.Point(0, 0);
            this.deckWorkspace1.Name = "deckWorkspace1";
            this.deckWorkspace1.Size = new System.Drawing.Size(634, 417);
            this.deckWorkspace1.TabIndex = 0;
            this.deckWorkspace1.Text = "deckWorkspace1";
            // 
            // userControl11
            // 
            this.userControl11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.userControl11.Location = new System.Drawing.Point(43, 137);
            this.userControl11.Name = "userControl11";
            this.userControl11.Size = new System.Drawing.Size(321, 87);
            this.userControl11.TabIndex = 1;
            // 
            // userControl21
            // 
            this.userControl21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.userControl21.Location = new System.Drawing.Point(43, 44);
            this.userControl21.Name = "userControl21";
            this.userControl21.Size = new System.Drawing.Size(321, 87);
            this.userControl21.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 417);
            this.Controls.Add(this.userControl21);
            this.Controls.Add(this.userControl11);
            this.Controls.Add(this.deckWorkspace1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        internal Microsoft.Practices.CompositeUI.WinForms.DeckWorkspace deckWorkspace1;
        private SmartPartUserControl userControl11;
        private NormalUserControl userControl21;

    }
}

