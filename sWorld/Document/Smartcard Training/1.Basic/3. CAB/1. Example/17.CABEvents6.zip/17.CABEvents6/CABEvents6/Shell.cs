using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.EventBroker;

namespace CABEvents6
{
    public partial class Shell : Form
    {
        public Shell()
        {
            InitializeComponent();
        }

        private WorkItem rootWorkItem;
        [ServiceDependency]
        public WorkItem RootWorkItem
        {
            set
            {
                rootWorkItem = value;
            }
        }

        // See Program.cs for comments on what this is doing
        private void fireGlobalButton_Click(object sender, EventArgs e)
        {
            rootWorkItem.EventTopics["MyEvent"].Fire(this, EventArgs.Empty, null, PublicationScope.Global);
        }

        private void eventsEnabledCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            rootWorkItem.EventTopics["MyEvent"].Enabled = eventTopicEnabledCheckbox.Checked;
        }        
    }
}