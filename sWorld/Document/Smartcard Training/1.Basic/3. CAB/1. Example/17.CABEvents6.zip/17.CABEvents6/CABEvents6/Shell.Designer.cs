namespace CABEvents6
{
    partial class Shell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fireGlobalButton = new System.Windows.Forms.Button();
            this.eventTopicEnabledCheckbox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // fireGlobalButton
            // 
            this.fireGlobalButton.Location = new System.Drawing.Point(31, 32);
            this.fireGlobalButton.Name = "fireGlobalButton";
            this.fireGlobalButton.Size = new System.Drawing.Size(110, 55);
            this.fireGlobalButton.TabIndex = 0;
            this.fireGlobalButton.Text = "Fire Global Event";
            this.fireGlobalButton.UseVisualStyleBackColor = true;
            this.fireGlobalButton.Click += new System.EventHandler(this.fireGlobalButton_Click);
            // 
            // eventTopicEnabledCheckbox
            // 
            this.eventTopicEnabledCheckbox.AutoSize = true;
            this.eventTopicEnabledCheckbox.Checked = true;
            this.eventTopicEnabledCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.eventTopicEnabledCheckbox.Location = new System.Drawing.Point(184, 32);
            this.eventTopicEnabledCheckbox.Name = "eventTopicEnabledCheckbox";
            this.eventTopicEnabledCheckbox.Size = new System.Drawing.Size(123, 17);
            this.eventTopicEnabledCheckbox.TabIndex = 3;
            this.eventTopicEnabledCheckbox.Text = "EventTopic Enabled";
            this.eventTopicEnabledCheckbox.UseVisualStyleBackColor = true;
            this.eventTopicEnabledCheckbox.CheckedChanged += new System.EventHandler(this.eventsEnabledCheckbox_CheckedChanged);
            // 
            // Shell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 163);
            this.Controls.Add(this.eventTopicEnabledCheckbox);
            this.Controls.Add(this.fireGlobalButton);
            this.Name = "Shell";
            this.Text = "CAB Disabling EventTopic Example";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button fireGlobalButton;
        private System.Windows.Forms.CheckBox eventTopicEnabledCheckbox;

    }
}

