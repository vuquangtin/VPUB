using System;
using Microsoft.Practices.CompositeUI.WinForms;
using Microsoft.Practices.CompositeUI;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.Commands;
using Microsoft.Practices.CompositeUI.EventBroker;

namespace CABEvents4
{
    public class Program : FormShellApplication<WorkItem, Shell>
    {
        [STAThread]
        static void Main()
        {
            new Program().Run();
        }
        protected override void AfterShellCreated()
        {
            base.AfterShellCreated();
            Subscriber subscriber = RootWorkItem.Items.AddNew<Subscriber>();

            // Make the click event of the button on the Shell form a 'Publication' for the MyEvent EventTopic.
            // The line below, and the EventSubscription attribute on our handler in the Subscriber class,
            // are all the code we need to get the click event of our button to call the event handler:
            // we don't need a .NET event handler in Shell for the button.
            RootWorkItem.EventTopics["MyEvent"].AddPublication(Shell.cabEventFirerButton, "Click", RootWorkItem, PublicationScope.Global);
        }
    }
}