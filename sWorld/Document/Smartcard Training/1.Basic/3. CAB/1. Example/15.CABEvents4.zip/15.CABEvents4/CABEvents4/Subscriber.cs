using System;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.EventBroker;
using Microsoft.Practices.CompositeUI;

namespace CABEvents4
{
    public class Subscriber
    {
        private WorkItem rootWorkItem;
        [ServiceDependency]
        public WorkItem RootWorkItem
        {
            set
            {
                rootWorkItem = value;
            }
        }

        [EventSubscription("MyEvent")]
        public void MyEventHandler(object sender, EventArgs e)
        {
            EventTopic et = rootWorkItem.EventTopics["MyEvent"];
            string message = "Event topic MyEvent.\r\n";
            message += "Number of publications = " + et.PublicationCount.ToString() + "\r\n";
            message += "Number of subscriptions = " + et.SubscriptionCount.ToString() + "\r\n";

            MessageBox.Show(message);
        }
    }
}
