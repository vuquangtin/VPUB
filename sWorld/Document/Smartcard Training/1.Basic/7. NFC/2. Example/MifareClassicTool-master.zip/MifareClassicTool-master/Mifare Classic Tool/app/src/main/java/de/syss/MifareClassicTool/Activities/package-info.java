/**
 * All Android Activities.
 */
package de.syss.MifareClassicTool.Activities;
