package com.minhnguyen.cardui;

/**
 * Created by minhnguyen on 2/27/17.
 */

public interface IDialogMonthSelectListener {
    void onFinishSelectMonthDialog(int month, int year);
}
