package com.minhnguyen.cardui;

/**
 * Created by minhnguyen on 2/15/17.
 */

public interface IDialogWriteTagsListener {
    void onNFCDialogDisplayed();

    void onNFCDialogDismissed();
}
